/**
 * FairFix Live Fair-Price Band Display Card & Chips - ProFlow Edition
 * The core platform differentiator: algorithmic fair bands with confidence & anti-gaming transparency.
 */
import React from 'react';
import { PriceBandResult, PriceComparison } from '../types.js';
import { TrendingUp, AlertTriangle, CheckCircle, Info, ShieldAlert } from 'lucide-react';

interface PriceBandCardProps {
  band: PriceBandResult | null;
  comparison?: PriceComparison | null;
  currentAmount?: number;
  compact?: boolean;
}

export const PriceBandCard: React.FC<PriceBandCardProps> = ({
  band,
  comparison,
  currentAmount,
  compact = false,
}) => {
  if (!band) {
    return (
      <div className="p-4 bg-[#FAF7F0] rounded-2xl border border-[#EBE5DB] animate-pulse text-xs text-[#646059]">
        Computing live fair-price band from nearby jobs...
      </div>
    );
  }

  const confidenceBadge = () => {
    switch (band.confidence) {
      case 'high':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
            <CheckCircle className="w-3 h-3 text-emerald-600" /> High Confidence ({band.jobCount} jobs)
          </span>
        );
      case 'low (few jobs)':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200">
            <AlertTriangle className="w-3 h-3 text-amber-600" /> Low ({band.jobCount} jobs)
          </span>
        );
      case 'estimate':
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-sky-800 bg-sky-50 px-2.5 py-0.5 rounded-full border border-sky-200">
            <Info className="w-3 h-3 text-sky-600" /> Baseline Estimate
          </span>
        );
    }
  };

  if (compact) {
    return (
      <div className="bg-white border border-[#EBE5DB] rounded-2xl p-3.5 shadow-xs">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <div className="flex items-center gap-1.5 font-bold text-[#141518]">
            <TrendingUp className="w-3.5 h-3.5 text-[#E85A32]" />
            <span>Fair-Price Band</span>
            <span className="text-[10px] text-[#646059] bg-[#F5F2EB] px-1.5 py-0.2 rounded-full border border-[#EBE5DB]">
              Live
            </span>
          </div>
          {confidenceBadge()}
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-lg font-black text-[#141518] tracking-tight">
            ₹{band.low.toLocaleString()} - ₹{band.high.toLocaleString()}
          </span>
          <span className="text-xs text-[#E85A32] font-semibold">
            (Median: ₹{band.typical.toLocaleString()})
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 sm:p-6 shadow-xs relative space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#FFF1EC] text-[#E85A32] flex items-center justify-center font-bold">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <h4 className="font-extrabold text-sm text-[#141518] flex items-center gap-1.5">
              Live Fair-Price Band
              <span className="text-[10px] font-normal uppercase tracking-wider text-[#646059] bg-[#F5F2EB] px-2 py-0.5 rounded-full border border-[#EBE5DB]">
                Verified
              </span>
            </h4>
            <p className="text-[11px] text-[#646059] capitalize">{band.category.replace('_', ' & ')} near you</p>
          </div>
        </div>
        {confidenceBadge()}
      </div>

      {/* Primary Band Numbers */}
      <div className="bg-[#FAF7F0] rounded-2xl p-4 border border-[#EBE5DB]">
        <div className="flex items-baseline justify-between">
          <div>
            <span className="text-xs text-[#646059] font-medium block">Fair Range</span>
            <span className="text-2xl font-black text-[#141518] tracking-tight">
              ₹{band.low.toLocaleString()} – ₹{band.high.toLocaleString()}
            </span>
          </div>
          <div className="text-right">
            <span className="text-xs text-[#E85A32] font-medium block">Typical (Median)</span>
            <span className="text-xl font-extrabold text-[#E85A32]">
              ₹{band.typical.toLocaleString()}
            </span>
          </div>
        </div>

        {/* Visual Range Bar */}
        <div className="mt-3 relative pt-2 pb-1">
          <div className="h-2.5 w-full bg-[#EBE5DB] rounded-full overflow-hidden flex">
            <div className="h-full bg-amber-100 w-1/4" title="Low percentile" />
            <div className="h-full bg-emerald-500 w-1/2 relative" title="Fair market band">
              <div className="absolute top-0 bottom-0 left-1/2 w-1 bg-[#121316] transform -translate-x-1/2" />
            </div>
            <div className="h-full bg-amber-100 w-1/4" title="High percentile" />
          </div>
          <div className="flex justify-between text-[10px] text-[#646059] mt-1 font-mono">
            <span>₹{band.low} (25th%)</span>
            <span className="text-[#141518] font-bold">Median (50th%)</span>
            <span>₹{band.high} (75th%)</span>
          </div>
        </div>
      </div>

      {/* Real-time Comparison Chip */}
      {comparison && currentAmount !== undefined && currentAmount > 0 && (
        <div>
          {comparison.status === 'within' ? (
            <div className="flex items-center gap-2 p-3 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <div>
                <span className="font-bold text-emerald-900">{comparison.label}</span>
                <span className="block text-[11px] text-emerald-700 mt-0.5">
                  Offers within this band have 88% higher acceptance rates.
                </span>
              </div>
            </div>
          ) : comparison.status === 'below' ? (
            <div className="flex items-start gap-2 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-950">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <div className="flex items-center gap-1.5 font-bold text-amber-900">
                  <span>{comparison.label}</span>
                  <span className="text-[10px] uppercase tracking-wide bg-amber-100 text-amber-900 px-2 py-0.2 rounded-full">
                    Notice
                  </span>
                </div>
                <p className="text-[11px] text-amber-800 mt-0.5">
                  {comparison.warning || 'Your offer is below typical market rate. Workers may counter-offer or take longer to respond.'}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-start gap-2 p-3 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-950">
              <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <div className="flex items-center gap-1.5 font-bold text-amber-900">
                  <span>{comparison.label}</span>
                  <span className="text-[10px] uppercase tracking-wide bg-amber-100 text-amber-900 px-2 py-0.2 rounded-full">
                    Above Band
                  </span>
                </div>
                <p className="text-[11px] text-amber-800 mt-0.5">
                  {comparison.warning || 'Offer is higher than typical fair range. You can proceed, but may be paying a premium.'}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Explanation string & Anti-gaming disclosure */}
      <div className="text-[11px] text-[#646059] flex items-start gap-2 bg-[#FAF7F0] p-3 rounded-2xl border border-[#EBE5DB]">
        <Info className="w-3.5 h-3.5 text-[#E85A32] shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <p className="text-[#141518] font-medium">{band.explanation}</p>
          <p className="text-[10px] text-[#646059]">
            Outliers rejected using 1.5&times;IQR rule &bull; Max 2 jobs/pair/week anti-gaming cap &bull; Max &plusmn;10% weekly velocity.
          </p>
        </div>
      </div>
    </div>
  );
};
