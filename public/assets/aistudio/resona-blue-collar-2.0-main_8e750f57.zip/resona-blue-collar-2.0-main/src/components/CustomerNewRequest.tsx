/**
 * FairFix Customer View - "ProFlow Modern" Edition
 * Warm luminous atmosphere, electric-yellow CTA pills, terracotta accents,
 * hero visual with floating glass rating badge, About Us section,
 * 4-step process cards, and 100% preserved booking and negotiation logic.
 */
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDemoUser } from '../context/DemoUserContext.js';
import { SERVICE_CATEGORIES, NEIGHBORHOODS, getCategoryLabel } from '../config.js';
import { PriceBandResult, MatchedWorker } from '../types.js';
import { MapPicker } from './MapPicker.js';
import { PriceBandGauge } from './PriceBandGauge.js';
import { 
  HudPanel, 
  ForgeButton, 
  Badge, 
  Drawer, 
  EmptyState, 
  formatINR 
} from './ui/index.js';
import { NegotiationThread } from './NegotiationThread.js';
import { 
  Wrench, 
  Zap, 
  Sparkles, 
  Fan, 
  Hammer, 
  Utensils, 
  MapPin, 
  CheckCircle2, 
  Clock, 
  Star, 
  Phone, 
  Search, 
  ShieldCheck, 
  Send, 
  MessageSquare, 
  Handshake, 
  ArrowRight, 
  ChevronRight,
  ShieldAlert,
  ArrowUpRight
} from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  plumbing: <Wrench className="w-5 h-5" />,
  electrician: <Zap className="w-5 h-5" />,
  cleaning: <Sparkles className="w-5 h-5" />,
  appliance: <Fan className="w-5 h-5" />,
  carpentry: <Hammer className="w-5 h-5" />,
  cook_maid: <Utensils className="w-5 h-5" />,
};

const sampleDescriptions: Record<string, string[]> = {
  plumbing: [
    'Kitchen sink faucet dripping constantly and pipe joint loose',
    'Bathroom flush tank leaking water onto the floor',
    'Main bathroom shower mixer pressure very low',
  ],
  electrician: [
    'Ceiling fan making vibrating rattling noise and wobbling',
    'Living room MCB tripping whenever inverter turns on',
    'Install 2 new modular switchboards and geyser point',
  ],
  cleaning: [
    'Full deep cleaning of 2BHK flat including balcony & kitchen tiles',
    'Bathroom tile descaling and disinfectant scrubbing',
    'Sofa and fabric upholstery shampooing',
  ],
  appliance: [
    '1.5 Ton Split AC not cooling, blowing normal room air',
    'Front-load washing machine giving spin drain error',
    'Refrigerator freezer over-icing and lower cabin warm',
  ],
  carpentry: [
    'Fix wardrobe sliding door track and align bedroom hinges',
    'Wooden main door latch loose and scraping floor',
    'Living room wall shelf mounting and TV unit bracket fix',
  ],
  cook_maid: [
    'Daily North/South Indian dinner cooking for family of 4',
    'Morning meal preparation and kitchen dusting assistance',
  ],
};

const processDescriptions: Record<number, { title: string; desc: string }> = {
  1: {
    title: 'Category & Consultation',
    desc: 'Select your blue-collar trade category. The platform benchmarks live neighborhood rates against IQR historical bounds.',
  },
  2: {
    title: 'Neighborhood & Geofence',
    desc: 'Choose your location across Bengaluru hubs. Worker locations remain coarse-grid masked until quotes are agreed.',
  },
  3: {
    title: 'Fair Quote & 3-Round Negotiation',
    desc: 'Propose starting rates. Verified nearby workers review and counter-offer within strict 3-round alternating guardrails.',
  },
  4: {
    title: 'Live Tracking & Cash Settlement',
    desc: 'Track worker arrival with 100m geofence detection. Settle directly with verified cash on completion without cuts.',
  },
};

export const CustomerNewRequest: React.FC = () => {
  const { currentUser } = useDemoUser();

  const [customerSubTab, setCustomerSubTab] = useState<'create' | 'active'>('create');
  const [activeStep, setActiveStep] = useState<number>(1);
  const [category, setCategory] = useState<string>('plumbing');
  const [description, setDescription] = useState<string>('Kitchen sink faucet dripping constantly and pipe joint loose');
  const [lat, setLat] = useState<number>(currentUser?.lat || NEIGHBORHOODS[0].lat);
  const [lng, setLng] = useState<number>(currentUser?.lng || NEIGHBORHOODS[0].lng);
  const [offeredPrice, setOfferedPrice] = useState<number>(450);

  // Price band states
  const [band, setBand] = useState<PriceBandResult | null>(null);

  // Matching results states
  const [matchingWorkers, setMatchingWorkers] = useState<MatchedWorker[]>([]);
  const [selectedWorker, setSelectedWorker] = useState<MatchedWorker | null>(null);
  const [matchedFetched, setMatchedFetched] = useState(false);
  const [searching, setSearching] = useState(false);
  const [jobCreatedSuccess, setJobCreatedSuccess] = useState<string | null>(null);

  // Active customer jobs for negotiation
  const [customerJobs, setCustomerJobs] = useState<any[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);

  const fetchCustomerJobs = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/jobs?customerId=${currentUser.id}`);
      if (!res.ok) return;
      const data = await res.json();
      setCustomerJobs(data);
    } catch (err) {
      console.error('Error fetching customer jobs:', err);
    }
  };

  useEffect(() => {
    fetchCustomerJobs();
    const interval = setInterval(fetchCustomerJobs, 3000);
    return () => clearInterval(interval);
  }, [currentUser]);

  // Sync coords when active customer changes
  useEffect(() => {
    if (currentUser) {
      setLat(currentUser.lat);
      setLng(currentUser.lng);
    }
  }, [currentUser]);

  // Fetch Live Fair-Price Band
  useEffect(() => {
    let isCancelled = false;
    const fetchBand = async () => {
      try {
        const url = `/api/price-band?category=${category}&lat=${lat}&lng=${lng}&price=${offeredPrice}&perspective=customer`;
        const res = await fetch(url);
        if (!res.ok) throw new Error('Failed to fetch band');
        const data = await res.json();
        if (!isCancelled) {
          setBand(data.band);
          if (data.band && offeredPrice === 450 && category !== 'plumbing') {
            setOfferedPrice(data.band.typical);
          }
        }
      } catch (err) {
        console.error('Error fetching price band:', err);
      }
    };

    fetchBand();
    return () => {
      isCancelled = true;
    };
  }, [category, lat, lng, offeredPrice]);

  // Handle Find Matching Workers
  const handleFindWorkers = async () => {
    setSearching(true);
    setJobCreatedSuccess(null);
    try {
      const res = await fetch(`/api/matching?category=${category}&lat=${lat}&lng=${lng}`);
      if (!res.ok) throw new Error('Matching query failed');
      const workers: MatchedWorker[] = await res.json();
      setMatchingWorkers(workers);
      setMatchedFetched(true);
      if (workers.length > 0) {
        setSelectedWorker(workers[0]);
      }
      // Scroll smoothly to results
      setTimeout(() => {
        const resultsEl = document.getElementById('matching-radar-section');
        resultsEl?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err) {
      console.error('Error matching workers:', err);
    } finally {
      setSearching(false);
    }
  };

  // Submit Job Request
  const handleCreateJob = async (workerId?: string) => {
    if (!currentUser) return;
    try {
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_id: currentUser.id,
          category,
          description,
          lat,
          lng,
          offered_price: offeredPrice,
          worker_id: workerId || selectedWorker?.id || null,
        }),
      });

      if (!res.ok) throw new Error('Failed to create job');
      const job = await res.json();
      setJobCreatedSuccess(`Job ${job.id.replace(/^job_/, '')} posted at ${formatINR(offeredPrice)}! Nearby worker notified.`);
      await fetchCustomerJobs();
      setSelectedJobId(job.id);
    } catch (err) {
      alert('Error creating job: ' + (err as Error).message);
    }
  };

  const steps = [
    { num: 1, label: 'Category' },
    { num: 2, label: 'Location' },
    { num: 3, label: 'Details' },
    { num: 4, label: 'Price Band' },
  ];

  const activeNegotiationsCount = customerJobs.filter((j) =>
    ['requested', 'negotiating'].includes(j.status)
  ).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-10">
      {/* Customer Mode Header Switcher: Request New Service vs Active Negotiations */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#EBE5DB] pb-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCustomerSubTab('create')}
            className={`px-5 py-2.5 rounded-full text-xs font-heading font-bold transition-all cursor-pointer flex items-center gap-2 ${
              customerSubTab === 'create'
                ? 'bg-[#121316] text-white shadow-sm'
                : 'bg-white text-[#646059] hover:text-[#141518] border border-[#EBE5DB]'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Request New Service</span>
          </button>

          <button
            onClick={() => setCustomerSubTab('active')}
            className={`px-5 py-2.5 rounded-full text-xs font-heading font-bold transition-all cursor-pointer flex items-center gap-2 ${
              customerSubTab === 'active'
                ? 'bg-[#121316] text-white shadow-sm'
                : 'bg-white text-[#646059] hover:text-[#141518] border border-[#EBE5DB]'
            }`}
          >
            <Handshake className="w-3.5 h-3.5" />
            <span>Active Requests &amp; Negotiations</span>
            {activeNegotiationsCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-[#FFEA00] text-[#121316] font-mono text-[10px] font-bold flex items-center justify-center">
                {activeNegotiationsCount}
              </span>
            )}
          </button>
        </div>

        <div className="text-right">
          <span className="text-xs text-[#646059] font-sans">
            Logged in Customer: <strong className="text-[#141518] font-heading font-bold">{currentUser?.name}</strong>
          </span>
        </div>
      </div>

      {jobCreatedSuccess && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-5 bg-emerald-50 border border-emerald-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-emerald-900 shadow-sm"
        >
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            <div>
              <p className="font-heading font-bold text-sm text-emerald-950">{jobCreatedSuccess}</p>
              <p className="text-xs text-emerald-700 mt-0.5 font-sans">
                Awaiting worker response. You can open the Negotiation Console now or switch to the Worker portal to test counter-offering.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <ForgeButton
              size="sm"
              icon={Handshake}
              onClick={() => {
                setCustomerSubTab('active');
                setJobCreatedSuccess(null);
              }}
            >
              Negotiation Hub
            </ForgeButton>
            <button
              onClick={() => setJobCreatedSuccess(null)}
              className="px-3 py-1.5 rounded-full bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-heading font-bold text-xs"
            >
              Dismiss
            </button>
          </div>
        </motion.div>
      )}

      {customerSubTab === 'active' ? (
        /* ACTIVE REQUESTS VIEW */
        <div className="space-y-6">
          <HudPanel variant="default" className="p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="pro-eyebrow mb-1">Live Negotiation Hub</span>
              <h2 className="font-heading text-2xl font-extrabold text-[#141518] mt-1">
                Active Requests &amp; Negotiated Jobs
              </h2>
              <p className="text-xs text-[#646059] mt-1 font-sans">
                Review counter-offers from nearby workers, accept agreed rates, or propose counter-offers (max 3 rounds).
              </p>
            </div>
            <ForgeButton
              size="sm"
              icon={Send}
              onClick={() => setCustomerSubTab('create')}
            >
              Request New Service
            </ForgeButton>
          </HudPanel>

          {customerJobs.length === 0 ? (
            <EmptyState
              icon={Handshake}
              title="No service requests placed yet"
              description="Pick a service category and post a request to start receiving and negotiating quotes from verified nearby workers."
              action={{
                label: 'Create First Request',
                onClick: () => setCustomerSubTab('create'),
              }}
            />
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {customerJobs.map((j) => {
                const latest = j.latest_offer || (j.offers && j.offers[j.offers.length - 1]);
                const isAccepted = ['accepted', 'in_progress', 'completed', 'rated'].includes(j.status);
                const isMyTurn = ['requested', 'negotiating'].includes(j.status) && latest?.from_role === 'worker';

                let statusBadgeVariant: 'fair' | 'caution' | 'danger' | 'neutral' = 'neutral';
                if (isAccepted) statusBadgeVariant = 'fair';
                else if (j.status === 'negotiating') statusBadgeVariant = 'caution';
                else if (j.status === 'cancelled') statusBadgeVariant = 'danger';

                return (
                  <div
                    key={j.id}
                    onClick={() => setSelectedJobId(j.id)}
                    className={`p-5 rounded-2xl border transition-all cursor-pointer bg-white ${
                      isMyTurn 
                        ? 'border-[#FFEA00] ring-2 ring-[#FFEA00]/60 shadow-md' 
                        : 'border-[#EBE5DB] hover:border-[#D5CEBF] shadow-xs'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      {/* Left: Job Meta & Category */}
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono text-xs text-[#99948B]">Job {j.id.replace(/^job_/, '')}</span>
                          <span className="font-heading font-extrabold text-sm text-[#141518]">
                            {getCategoryLabel(j.category)}
                          </span>
                          <Badge variant={statusBadgeVariant} size="sm">
                            {j.status.toUpperCase()}
                          </Badge>
                          {isMyTurn && (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-heading font-bold uppercase tracking-wider bg-[#FFEA00] text-[#121316]">
                              Action Required: Worker Countered
                            </span>
                          )}
                          {j.status === 'completed' && (
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-heading font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800">
                              Action Required: Rate Service
                            </span>
                          )}
                          {latest && (
                            <span className="text-[11px] font-mono text-[#646059]">
                              Round {latest.round}/3
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-[#141518] font-sans line-clamp-2">
                          {j.description}
                        </p>

                        <div className="flex items-center gap-3 text-xs text-[#646059] font-sans">
                          <span>
                            Worker: <strong className="text-[#141518]">{j.worker_name || 'Broadcasting to nearby'}</strong>
                          </span>
                          <span>&bull;</span>
                          <span className="font-mono">
                            {new Date(j.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          {j.customer_phone && isAccepted && j.status !== 'rated' && (
                            <>
                              <span>&bull;</span>
                              <span className="text-emerald-700 font-mono font-bold flex items-center gap-1">
                                <Phone className="w-3.5 h-3.5" />
                                {j.worker_phone || 'Direct line'}
                              </span>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Right: Pricing & CTA */}
                      <div className="flex items-center justify-between md:justify-end gap-4 shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-[#EBE5DB]">
                        <div className="text-right">
                          <div className="text-[10px] uppercase font-mono text-[#99948B]">
                            {isAccepted ? 'Agreed Price' : 'Latest Offer'}
                          </div>
                          <div className="font-heading text-xl font-extrabold text-[#141518] tabular-nums">
                            {formatINR(j.agreed_price || latest?.amount || j.offered_price)}
                          </div>
                        </div>

                        <ForgeButton
                          variant={isMyTurn || j.status === 'completed' ? 'primary' : 'ghost'}
                          size="sm"
                          icon={MessageSquare}
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedJobId(j.id);
                          }}
                        >
                          {j.status === 'completed'
                            ? 'Rate Worker'
                            : j.status === 'rated'
                            ? 'View Rating'
                            : j.status === 'in_progress'
                            ? 'Track Service'
                            : isMyTurn
                            ? 'Respond & Negotiate'
                            : isAccepted
                            ? 'View Contact'
                            : 'View Negotiation'}
                        </ForgeButton>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* CREATE SERVICE VIEW: HERO + ABOUT US + HOW IT WORKS + BOOKING FORM */
        <>
          {/* ========================================================== */}
          {/* 1. HERO SECTION (MATCHING REFERENCE IMAGE 1 EXACTLY)       */}
          {/* ========================================================== */}
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-b from-[#F6E38E]/55 via-[#FAF2CA]/35 to-transparent border border-[#F0E4B8]/60 p-6 sm:p-10 md:p-14 shadow-sm">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              {/* Left Column: Eyebrow, Hero Title, CTA, Stats */}
              <div className="lg:col-span-6 space-y-6 z-10">
                <div className="inline-block">
                  <span className="pro-eyebrow">• FAIRFIX BLUE-COLLAR SERVICES</span>
                </div>

                <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl font-extrabold text-[#141518] leading-[1.06] tracking-tight">
                  Expert Services,<br />
                  Perfected<br />
                  Spaces
                </h1>

                <p className="text-sm sm:text-base text-[#555047] max-w-md font-sans leading-relaxed">
                  Hyperlocal on-demand repairs governed by an automated, live fair-price band. Verified local mechanics, zero aggregator commissions.
                </p>

                {/* Primary Yellow Pill Button with Signature Black Arrow Badge */}
                <div className="pt-2">
                  <button
                    onClick={() => {
                      const el = document.getElementById('booking-section');
                      el?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="pro-pill-yellow text-sm sm:text-base group"
                  >
                    <span>Get a Free Quote</span>
                    <span className="pro-arrow-badge">↗</span>
                  </button>
                </div>

                {/* Live Metrics Row (200+ Completed Projects, 100% Satisfaction) */}
                <div className="flex items-center gap-10 pt-4 border-t border-[#E8DEC4]">
                  <div>
                    <div className="font-heading text-2xl sm:text-3xl font-extrabold text-[#E85A32]">
                      200+
                    </div>
                    <div className="text-xs text-[#646059] font-heading font-medium mt-0.5">
                      Completed Projects
                    </div>
                  </div>
                  <div>
                    <div className="font-heading text-2xl sm:text-3xl font-extrabold text-[#E85A32]">
                      100%
                    </div>
                    <div className="text-xs text-[#646059] font-heading font-medium mt-0.5">
                      Clients satisfaction
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: Hero Tradesperson Image & Floating Rating Badge */}
              <div className="lg:col-span-6 relative flex items-center justify-center lg:justify-end">
                <div className="relative max-w-[480px] w-full">
                  <img
                    src="/hero_worker.png"
                    alt="Professional Tradesperson"
                    className="w-full h-auto object-contain drop-shadow-xl"
                  />

                  {/* Floating Smoked Glass Card (from reference Image 1) */}
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="absolute bottom-4 right-2 sm:bottom-6 sm:right-6 pro-glass-badge max-w-[210px] w-full"
                  >
                    <div className="text-[11px] text-[#D5CEBF] font-heading font-medium">
                      Trusted Experts
                    </div>
                    <div className="flex items-center gap-1.5 my-1">
                      <span className="font-heading text-2xl font-black text-white">4.9</span>
                      <span className="text-[#FFEA00] text-lg font-bold">★</span>
                    </div>
                    {/* Avatar stack + 50+ */}
                    <div className="flex items-center -space-x-2 pt-1">
                      <div className="w-6 h-6 rounded-full bg-neutral-200 border-2 border-[#121316] overflow-hidden flex items-center justify-center text-[9px] font-bold text-black">
                        👩
                      </div>
                      <div className="w-6 h-6 rounded-full bg-neutral-300 border-2 border-[#121316] overflow-hidden flex items-center justify-center text-[9px] font-bold text-black">
                        👨
                      </div>
                      <div className="w-6 h-6 rounded-full bg-neutral-400 border-2 border-[#121316] overflow-hidden flex items-center justify-center text-[9px] font-bold text-black">
                        🧑
                      </div>
                      <div className="w-6 h-6 rounded-full bg-[#E85A32] text-white border-2 border-[#121316] flex items-center justify-center text-[8px] font-bold font-mono pl-0.5">
                        50+
                      </div>
                    </div>
                  </motion.div>
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================== */}
          {/* 2. ABOUT US SECTION (MATCHING REFERENCE IMAGE 2 BOTTOM)    */}
          {/* ========================================================== */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-white border border-[#EBE5DB] rounded-3xl p-6 sm:p-10 shadow-xs">
            {/* Left: Team Photo with Rounded Borders */}
            <div className="lg:col-span-5">
              <div className="rounded-2xl overflow-hidden bg-[#FAF7F0] border border-[#EBE5DB] shadow-sm">
                <img
                  src="/team_photo.png"
                  alt="FairFix Blue Collar Services Team"
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>

            {/* Right: Statement, CTA, Stat Counters */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <span className="pro-eyebrow">• ABOUT US</span>
                <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#141518] mt-2 leading-snug">
                  FairFix provides reliable and professional home services to <span className="text-[#646059]">keep your home fresh, healthy, and comfortable. Our trained</span>
                </h2>
              </div>

              <div>
                <button
                  onClick={() => {
                    const el = document.getElementById('booking-section');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="pro-pill-yellow text-xs sm:text-sm py-2 px-4 group"
                >
                  <span>More About Us</span>
                  <span className="pro-arrow-badge !w-5 !h-5 !text-[10px]">↗</span>
                </button>
              </div>

              {/* Stat Counters */}
              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#EBE5DB]">
                <div>
                  <div className="font-heading text-2xl sm:text-3xl font-extrabold text-[#E85A32]">24/7</div>
                  <div className="text-[11px] text-[#646059] font-heading font-medium mt-0.5">Emergency Response</div>
                </div>
                <div>
                  <div className="font-heading text-2xl sm:text-3xl font-extrabold text-[#E85A32]">15+</div>
                  <div className="text-[11px] text-[#646059] font-heading font-medium mt-0.5">Years in Business</div>
                </div>
                <div>
                  <div className="font-heading text-2xl sm:text-3xl font-extrabold text-[#E85A32]">100%</div>
                  <div className="text-[11px] text-[#646059] font-heading font-medium mt-0.5">Fair Band Protection</div>
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================== */}
          {/* 3. HOW IT WORKS / PROCESS SECTION (IMAGE 2 TOP-RIGHT)     */}
          {/* ========================================================== */}
          <div className="bg-[#FAF7F0] border border-[#EBE5DB] rounded-3xl p-6 sm:p-10 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="pro-eyebrow">• HOW IT WORKS</span>
                <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#141518] mt-1">
                  Simple, Transparent 4-Step Process
                </h2>
              </div>
              <span className="text-xs text-[#646059] font-sans">
                Click any step to jump straight to that booking stage
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Left Column: 4 Step Cards */}
              <div className="lg:col-span-6 flex flex-col justify-between gap-3">
                {[
                  { num: 1, title: 'Category & Consultation' },
                  { num: 2, title: 'Inspection & Location' },
                  { num: 3, title: 'Fair Quote & Negotiation' },
                  { num: 4, title: 'Final Check & Cleanup' },
                ].map((s) => {
                  const isActive = activeStep === s.num;
                  return (
                    <button
                      key={s.num}
                      onClick={() => {
                        setActiveStep(s.num);
                        const el = document.getElementById('booking-section');
                        el?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className={`p-4 rounded-2xl text-left transition-all duration-200 cursor-pointer flex items-center justify-between ${
                        isActive
                          ? 'bg-[#121316] text-white shadow-md'
                          : 'bg-white text-[#141518] hover:bg-neutral-50 border border-[#EBE5DB]'
                      }`}
                    >
                      <div>
                        <div className={`text-[10px] font-heading font-bold uppercase tracking-wider ${isActive ? 'text-[#E85A32]' : 'text-[#E85A32]'}`}>
                          Step {s.num}
                        </div>
                        <div className="font-heading font-extrabold text-sm sm:text-base mt-0.5">
                          {s.title}
                        </div>
                      </div>
                      <ChevronRight className={`w-4 h-4 ${isActive ? 'text-white' : 'text-[#99948B]'}`} />
                    </button>
                  );
                })}
              </div>

              {/* Right Column: Active Step Details & Photo */}
              <div className="lg:col-span-6 bg-white border border-[#EBE5DB] rounded-2xl p-5 flex flex-col justify-between shadow-xs">
                <div className="rounded-xl overflow-hidden bg-neutral-100 mb-4 h-48 sm:h-52">
                  <img
                    src="/process_photo.png"
                    alt="Process Illustration"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <span className="text-[10px] font-heading font-bold uppercase text-[#E85A32]">
                    Current Phase: Step {activeStep}
                  </span>
                  <h3 className="font-heading text-lg font-extrabold text-[#141518] mt-1">
                    {processDescriptions[activeStep]?.title}
                  </h3>
                  <p className="text-xs text-[#646059] font-sans mt-1.5 leading-relaxed">
                    {processDescriptions[activeStep]?.desc}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================== */}
          {/* 4. INTERACTIVE BOOKING WORKSPACE & MATCHING SECTION         */}
          {/* ========================================================== */}
          <div id="booking-section" className="space-y-6 pt-4">
            {/* Header with Step Tracker */}
            <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <span className="pro-eyebrow">• CORE SERVICES &amp; DISPATCH</span>
                <h2 className="font-heading text-2xl font-extrabold text-[#141518] mt-1">
                  Request On-Demand Service
                </h2>
                <p className="text-xs text-[#646059] mt-0.5 font-sans">
                  Live IQR price band computed from completed jobs &bull; Straight-line 20 km/h city travel ETA.
                </p>
              </div>

              {/* Stepper Pills */}
              <div className="flex items-center gap-1.5 bg-[#F5F2EB] p-1.5 rounded-full border border-[#EBE5DB]">
                {steps.map((s, idx) => {
                  const isPastOrActive = activeStep >= s.num;
                  const isCurrent = activeStep === s.num;
                  return (
                    <div key={s.num} className="flex items-center">
                      <button
                        onClick={() => setActiveStep(s.num)}
                        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-heading font-bold transition cursor-pointer ${
                          isCurrent
                            ? 'bg-[#121316] text-white shadow-xs'
                            : isPastOrActive
                            ? 'text-[#141518] hover:text-black'
                            : 'text-[#99948B]'
                        }`}
                      >
                        <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-mono ${isCurrent ? 'bg-[#FFEA00] text-black font-extrabold' : 'bg-neutral-200 text-neutral-700'}`}>
                          {s.num}
                        </span>
                        <span className="hidden sm:inline">{s.label}</span>
                      </button>
                      {idx < steps.length - 1 && (
                        <div className="w-2.5 h-0.5 bg-[#EBE5DB] mx-0.5" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Main Form Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Column: Form Controls */}
              <div className="lg:col-span-7 space-y-5">
                {/* 1. Category Selection Cards */}
                <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 sm:p-6 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-heading font-bold uppercase tracking-wider text-[#141518]">
                      1. Select Category
                    </label>
                    <span className="text-xs text-[#E85A32] font-heading font-bold">
                      {getCategoryLabel(category)}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {SERVICE_CATEGORIES.map((cat) => {
                      const isSelected = category === cat.id;
                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => {
                            setCategory(cat.id);
                            setActiveStep(2);
                            const presets = sampleDescriptions[cat.id];
                            if (presets && presets[0]) setDescription(presets[0]);
                          }}
                          className={`relative p-3.5 rounded-2xl text-left transition duration-200 cursor-pointer flex flex-col justify-between min-h-[105px] ${
                            isSelected
                              ? 'bg-[#FAF7F0] border-2 border-[#121316] shadow-sm text-[#141518]'
                              : 'bg-white hover:bg-[#FAF7F0] border border-[#EBE5DB] text-[#646059]'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full">
                            <div
                              className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                                isSelected
                                  ? 'bg-[#121316] text-[#FFEA00] shadow-sm'
                                  : 'bg-[#F5F2EB] text-[#141518]'
                              }`}
                            >
                              {iconMap[cat.id]}
                            </div>
                            {cat.id === 'cook_maid' && (
                              <span className="text-[9px] font-heading font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded-full border border-amber-200">
                                Low Conf
                              </span>
                            )}
                          </div>
                          <div>
                            <p className="font-heading font-extrabold text-xs text-[#141518] mt-2">{cat.name}</p>
                            <p className="text-[11px] text-[#646059] font-mono mt-0.5">Base: ~{formatINR(cat.baselinePrice)}</p>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Interactive Map with Neighborhood Presets */}
                <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 sm:p-6 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-heading font-bold uppercase tracking-wider text-[#141518] flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#E85A32]" />
                      2. Neighborhood &amp; Location
                    </label>
                    <div className="flex items-center gap-1 flex-wrap text-xs">
                      <span className="text-[#646059] hidden sm:inline">Presets:</span>
                      {NEIGHBORHOODS.slice(0, 3).map((n) => (
                        <button
                          key={n.id}
                          type="button"
                          onClick={() => {
                            setLat(n.lat);
                            setLng(n.lng);
                            setActiveStep(3);
                          }}
                          className="px-2.5 py-1 rounded-full bg-[#F5F2EB] hover:bg-[#EBE5DB] text-[#141518] border border-[#EBE5DB] font-heading text-[10px] font-bold uppercase cursor-pointer"
                        >
                          {n.name.split(' ')[0]}
                        </button>
                      ))}
                    </div>
                  </div>

                  <MapPicker
                    lat={lat}
                    lng={lng}
                    onLocationChange={(newLat, newLng) => {
                      setLat(newLat);
                      setLng(newLng);
                      setActiveStep(3);
                    }}
                    interactivePin={true}
                    radiusKm={5}
                    heightClass="h-64 sm:h-72"
                  />
                  <div className="flex items-center justify-between text-xs text-[#646059] font-mono">
                    <span>Pin: {lat.toFixed(4)}, {lng.toFixed(4)}</span>
                    <span className="text-emerald-700 font-bold">Search radius: 5.0 km</span>
                  </div>
                </div>

                {/* 3. Issue Description */}
                <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 sm:p-6 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-heading font-bold uppercase tracking-wider text-[#141518]">
                      3. Describe Service Issue
                    </label>
                    <span className="text-[11px] text-[#99948B]">Click preset to fill:</span>
                  </div>

                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => {
                      setDescription(e.target.value);
                      setActiveStep(4);
                    }}
                    placeholder="e.g. Leaking kitchen tap joint..."
                    className="w-full bg-[#FAF7F0] border border-[#EBE5DB] rounded-2xl px-4 py-3 text-xs text-[#141518] placeholder-[#99948B] focus:outline-none focus:border-[#121316] transition font-sans"
                  />

                  {sampleDescriptions[category] && (
                    <div className="flex flex-wrap gap-1.5">
                      {sampleDescriptions[category].map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => {
                            setDescription(preset);
                            setActiveStep(4);
                          }}
                          className="text-[11px] bg-[#F5F2EB] hover:bg-[#EBE5DB] text-[#555047] hover:text-[#141518] px-3 py-1.5 rounded-full border border-[#EBE5DB] transition text-left cursor-pointer font-sans"
                        >
                          &ldquo;{preset.slice(0, 36)}...&rdquo;
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* 4. Offered Price Input */}
                <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 sm:p-6 shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-heading font-bold uppercase tracking-wider text-[#141518]">
                      4. Starting Offered Price
                    </label>
                    {band && (
                      <span className="text-xs text-emerald-800 font-mono font-bold">
                        Median: {formatINR(band.typical)}
                      </span>
                    )}
                  </div>

                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 font-heading font-bold text-[#99948B] text-xl">
                      ₹
                    </span>
                    <input
                      type="number"
                      min={50}
                      step={25}
                      value={offeredPrice || ''}
                      onChange={(e) => setOfferedPrice(Number(e.target.value))}
                      className="w-full bg-[#FAF7F0] border border-[#EBE5DB] rounded-2xl pl-10 pr-4 py-3 font-heading text-2xl font-black text-[#141518] focus:outline-none focus:border-[#121316] tabular-nums"
                    />
                  </div>
                </div>

                {/* Find Nearby Workers CTA */}
                <button
                  type="button"
                  onClick={handleFindWorkers}
                  disabled={searching}
                  className="pro-pill-yellow !w-full justify-center !py-3.5 !text-base shadow-md disabled:opacity-50"
                >
                  <Search className="w-5 h-5 mr-1" />
                  <span>{searching ? 'Scanning Nearby Workers...' : 'Find Nearby Workers'}</span>
                  <span className="pro-arrow-badge !w-6 !h-6 !text-xs">↗</span>
                </button>
              </div>

              {/* Right Column: Hero PriceBandGauge & Trust Guarantees */}
              <div className="lg:col-span-5 space-y-5">
                <PriceBandGauge
                  band={band}
                  currentPrice={offeredPrice}
                  perspective="customer"
                  onPriceChange={(newPrice) => setOfferedPrice(newPrice)}
                />

                {/* Platform Guarantees Card */}
                <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 sm:p-6 shadow-xs space-y-3 text-xs text-[#646059]">
                  <h5 className="font-heading font-bold text-[#141518] text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    Platform Guarantees &amp; Truth
                  </h5>
                  <ul className="space-y-2 text-xs leading-relaxed font-sans">
                    <li className="flex items-start gap-2">
                      <span className="text-[#E85A32] font-bold">&bull;</span>
                      <span><strong>No Price Gouging:</strong> Fair bands are calculated from real completed jobs within 10 km. Outliers removed via IQR rule.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#E85A32] font-bold">&bull;</span>
                      <span><strong>Anti-Gaming:</strong> Maximum 2 jobs per customer-worker pair per 7-day period to prevent synthetic price manipulation.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#E85A32] font-bold">&bull;</span>
                      <span><strong>Travel Estimation:</strong> ETA estimated from straight-line distance at 20 km/h city travel speed.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#E85A32] font-bold">&bull;</span>
                      <span><strong>Phone Privacy:</strong> Direct phone numbers remain masked until a job quote is formally accepted.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* ========================================================== */}
            {/* 5. MATCHING RADAR RESULTS SECTION                         */}
            {/* ========================================================== */}
            {matchedFetched && (
              <div id="matching-radar-section" className="space-y-6 pt-8 border-t border-[#EBE5DB]">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="pro-eyebrow">• MATCHING RADAR</span>
                    <h2 className="font-heading text-2xl font-extrabold text-[#141518] mt-1 flex items-center gap-2">
                      <span>{matchingWorkers.length} Available Worker{matchingWorkers.length === 1 ? '' : 's'} Nearby</span>
                      <span className="text-xs font-normal text-[#646059] font-sans">(Verified first, then shortest ETA)</span>
                    </h2>
                  </div>
                  <span className="text-xs text-[#99948B] font-mono">
                    Phone numbers masked until accepted
                  </span>
                </div>

                {matchingWorkers.length === 0 ? (
                  <EmptyState
                    icon={Search}
                    title="No available workers found within radius"
                    description="Try switching active neighbourhood or expanding the service category. You can also toggle worker availability in the Worker Portal."
                    action={{
                      label: 'Expand Category',
                      onClick: () => setActiveStep(1),
                    }}
                  />
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* Workers List */}
                    <div className="lg:col-span-7 space-y-3">
                      {matchingWorkers.map((w, index) => {
                        const isVerified = w.verification_status === 'verified';
                        const isSelected = selectedWorker?.id === w.id;

                        let bandChipVariant: 'fair' | 'caution' = 'fair';
                        let bandChipText = 'Within band';
                        if (band) {
                          if (w.base_rate < band.low) {
                            bandChipVariant = 'caution';
                            bandChipText = 'Below band';
                          } else if (w.base_rate > band.high) {
                            bandChipVariant = 'caution';
                            bandChipText = 'Above band';
                          }
                        }

                        const displayName = w.name.length > 24 ? `${w.name.slice(0, 24)}...` : w.name;

                        return (
                          <motion.div
                            key={w.id}
                            initial={{ opacity: 0, y: 12 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.04, duration: 0.25 }}
                            onClick={() => setSelectedWorker(w)}
                            className={`p-5 rounded-3xl border transition cursor-pointer bg-white ${
                              isSelected
                                ? 'border-[#121316] ring-2 ring-[#FFEA00] shadow-md'
                                : 'border-[#EBE5DB] hover:border-[#D5CEBF] shadow-xs'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              {/* Worker Identity */}
                              <div className="flex items-start gap-3">
                                <div className="w-11 h-11 rounded-2xl bg-[#121316] text-[#FFEA00] flex items-center justify-center font-heading font-extrabold text-sm shrink-0 shadow-xs">
                                  {w.name.charAt(0)}
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <h3 className="font-heading font-extrabold text-sm sm:text-base text-[#141518]" title={w.name}>
                                      {displayName}
                                    </h3>
                                    {isVerified ? (
                                      <Badge variant="verified" size="sm">
                                        Verified
                                      </Badge>
                                    ) : (
                                      <Badge variant="neutral" size="sm">
                                        {w.verification_status}
                                      </Badge>
                                    )}
                                    {index === 0 && (
                                      <span className="text-[10px] font-heading font-bold uppercase tracking-wider bg-[#FFEA00] text-[#121316] px-2 py-0.5 rounded-full">
                                        Best Match
                                      </span>
                                    )}
                                  </div>

                                  <div className="flex flex-wrap items-center gap-2.5 text-xs text-[#646059] mt-1 font-sans">
                                    <span className="flex items-center gap-1 text-[#141518] font-bold font-heading">
                                      <Star className="w-3.5 h-3.5 fill-[#FFEA00] text-[#FFEA00]" />
                                      {w.rating_avg}
                                      <span className="text-[#99948B] font-normal">({w.rating_count} reviews)</span>
                                    </span>
                                    <span>&bull;</span>
                                    <span className="text-[#141518] font-medium">{w.jobs_completed} jobs</span>
                                    <span>&bull;</span>
                                    <span className="text-[#646059] font-mono">{w.distance_km} km away</span>
                                  </div>
                                </div>
                              </div>

                              {/* Rate and ETA */}
                              <div className="text-right shrink-0">
                                <div className="font-heading text-base font-extrabold text-[#141518] tabular-nums">
                                  {formatINR(w.base_rate)}
                                  <span className="text-[10px] text-[#646059] font-normal font-sans"> / job</span>
                                </div>
                                <div className="inline-flex items-center gap-1 text-xs font-mono font-bold text-emerald-700 mt-0.5">
                                  <Clock className="w-3 h-3" />
                                  <span>{w.eta_label}</span>
                                </div>
                              </div>
                            </div>

                            {/* Bottom Bar: Masked Phone & Direct Action */}
                            <div className="mt-4 pt-3 border-t border-[#EBE5DB] flex items-center justify-between text-xs">
                              <div className="flex items-center gap-2">
                                <div className="flex items-center gap-1.5 text-[#99948B] font-mono text-[11px]">
                                  <Phone className="w-3.5 h-3.5 text-[#99948B]" />
                                  <span>{w.phone}</span>
                                </div>
                                <Badge variant={bandChipVariant} size="sm">
                                  {bandChipText}
                                </Badge>
                              </div>

                              <ForgeButton
                                size="sm"
                                icon={Send}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleCreateJob(w.id);
                                }}
                              >
                                Request at {formatINR(offeredPrice)}
                              </ForgeButton>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>

                    {/* Map View of Results */}
                    <div className="lg:col-span-5 space-y-3">
                      <div className="bg-white border border-[#EBE5DB] rounded-3xl p-4 shadow-xs">
                        <div className="flex items-center justify-between mb-2 px-1">
                          <span className="text-xs font-heading font-bold text-[#141518] uppercase tracking-wider flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-[#E85A32]" />
                            Worker Radar Map
                          </span>
                          <span className="text-[10px] font-mono text-[#646059]">
                            5 km search radius
                          </span>
                        </div>
                        <MapPicker
                          lat={lat}
                          lng={lng}
                          workers={matchingWorkers}
                          selectedWorkerId={selectedWorker?.id}
                          onSelectWorker={(w) => setSelectedWorker(w)}
                          radiusKm={5}
                          heightClass="h-80 sm:h-96"
                        />
                      </div>

                      {selectedWorker && (
                        <div className="bg-[#FAF7F0] border border-[#EBE5DB] rounded-2xl p-4 text-xs space-y-1">
                          <p className="font-heading font-extrabold text-[#141518]">
                            Selected Worker: {selectedWorker.name} ({selectedWorker.eta_label})
                          </p>
                          <p className="text-[#646059] text-[11px] font-mono">
                            Base rate: {formatINR(selectedWorker.base_rate)} &bull; Operational Radius: {selectedWorker.radius_km} km
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </>
      )}

      {/* Negotiation Thread Drawer for Customer */}
      <Drawer
        isOpen={Boolean(selectedJobId)}
        onClose={() => setSelectedJobId(null)}
        title="Job Negotiation Console"
      >
        {selectedJobId && (
          <NegotiationThread
            jobId={selectedJobId}
            onJobUpdated={fetchCustomerJobs}
            onClose={() => setSelectedJobId(null)}
          />
        )}
      </Drawer>
    </div>
  );
};
