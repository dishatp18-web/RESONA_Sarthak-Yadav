/**
 * FairFix Fair-Price Explorer - ProFlow Edition
 * Warm luminous atmosphere, category chips, neighborhood selectors,
 * PriceBandGauge hero, SVG price sparkline, and outlier inspection.
 */
import React, { useState, useEffect } from 'react';
import { SERVICE_CATEGORIES, NEIGHBORHOODS, getCategoryLabel } from '../config.js';
import { PriceBandResult } from '../types.js';
import { PriceBandGauge } from './PriceBandGauge.js';
import { Badge, formatINR } from './ui/index.js';
import { 
  TrendingUp, 
  MapPin, 
  Calculator, 
  Layers, 
  Activity,
  AlertTriangle,
  Info
} from 'lucide-react';

interface RecentJobPoint {
  id: string;
  price: number;
  date: string;
  isOutlier: boolean;
  reason?: string;
}

export const FairPriceExplorer: React.FC = () => {
  const [category, setCategory] = useState<string>('plumbing');
  const [selectedNeighborhood, setSelectedNeighborhood] = useState(NEIGHBORHOODS[0]);
  const [testAmount, setTestAmount] = useState<number>(450);

  const [band, setBand] = useState<PriceBandResult | null>(null);
  const [recentPoints, setRecentPoints] = useState<RecentJobPoint[]>([]);

  useEffect(() => {
    let isCancelled = false;
    const fetchBand = async () => {
      try {
        const res = await fetch(
          `/api/price-band?category=${category}&lat=${selectedNeighborhood.lat}&lng=${selectedNeighborhood.lng}&price=${testAmount}&perspective=customer`
        );
        if (!res.ok) throw new Error('Failed to load band');
        const data = await res.json();
        if (!isCancelled) {
          setBand(data.band);
        }
      } catch (err) {
        console.error('Error fetching explorer band:', err);
      }
    };

    fetchBand();
    return () => {
      isCancelled = true;
    };
  }, [category, selectedNeighborhood, testAmount]);

  // Fetch recent completed jobs for sparkline and outlier list
  useEffect(() => {
    let isCancelled = false;
    const fetchRecentJobs = async () => {
      try {
        const res = await fetch(`/api/jobs`);
        if (!res.ok) return;
        const allJobs = await res.json();
        const catJobs = allJobs.filter(
          (j: any) => j.category === category && ['completed', 'rated'].includes(j.status)
        );

        const sorted = catJobs.slice(0, 10);
        if (!isCancelled && band) {
          const iqrUpper = band.high + (band.high - band.low) * 1.5;
          const iqrLower = Math.max(50, band.low - (band.high - band.low) * 1.5);

          const points: RecentJobPoint[] = sorted.map((j: any) => {
            const price = Number(j.agreed_price || j.offered_price);
            const isOutlier = price > iqrUpper || price < iqrLower;
            return {
              id: j.id,
              price,
              date: j.completed_at || j.created_at,
              isOutlier,
              reason: isOutlier
                ? price > iqrUpper
                  ? `${formatINR(price)} exceeds upper fence (Q3 + 1.5*IQR)`
                  : `${formatINR(price)} below lower fence (Q1 - 1.5*IQR)`
                : undefined,
            };
          });
          setRecentPoints(points);
        }
      } catch (err) {
        console.error('Error loading recent job points:', err);
      }
    };

    fetchRecentJobs();
    return () => {
      isCancelled = true;
    };
  }, [category, band]);

  // Generate inline SVG sparkline path
  const renderSparkline = () => {
    if (recentPoints.length < 2) return null;

    const prices = recentPoints.map((p) => p.price);
    const min = Math.min(...prices) * 0.9;
    const max = Math.max(...prices) * 1.1;
    const range = max - min || 1;

    const width = 360;
    const height = 70;

    const coords = recentPoints.map((p, idx) => {
      const x = (idx / (recentPoints.length - 1)) * (width - 20) + 10;
      const y = height - 10 - ((p.price - min) / range) * (height - 20);
      return { x, y, point: p };
    });

    const pathD = coords.reduce((acc, c, i) => `${acc} ${i === 0 ? 'M' : 'L'} ${c.x} ${c.y}`, '');

    return (
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-20 overflow-visible">
        <defs>
          <linearGradient id="sparklineGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFEA00" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#FFEA00" stopOpacity="0" />
          </linearGradient>
        </defs>

        <path
          d={`${pathD} L ${coords[coords.length - 1].x} ${height} L ${coords[0].x} ${height} Z`}
          fill="url(#sparklineGrad)"
        />

        <path
          d={pathD}
          fill="none"
          stroke="#121316"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {coords.map((c, i) => (
          <g key={i}>
            <circle
              cx={c.x}
              cy={c.y}
              r={c.point.isOutlier ? 5 : 3.5}
              fill={c.point.isOutlier ? '#DC2626' : '#059669'}
              stroke="#FFFFFF"
              strokeWidth="2"
            />
          </g>
        ))}
      </svg>
    );
  };

  const outlierPoints = recentPoints.filter((p) => p.isOutlier);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Header Banner */}
      <div className="bg-white border border-[#EBE5DB] rounded-3xl p-6 sm:p-8 shadow-xs">
        <div>
          <span className="pro-eyebrow">• FAIR-PRICE ENGINE &amp; ANTI-GOUGING</span>
          <h1 className="font-heading text-3xl font-extrabold text-[#141518] mt-1.5">
            Live Fair-Price Band Monitor
          </h1>
          <p className="text-sm text-[#646059] mt-1.5 max-w-2xl font-sans leading-relaxed">
            Algorithmic price bands derived from real completed transactions across Bengaluru. Outliers eliminated via IQR 1.5x rule; weekly band shifts capped to &plusmn;10%.
          </p>
        </div>
      </div>

      {/* Selectors */}
      <div className="bg-white border border-[#EBE5DB] rounded-3xl p-6 shadow-xs space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Category Chips */}
          <div>
            <label className="block text-xs font-heading font-bold uppercase tracking-wider text-[#141518] mb-3">
              Select Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {SERVICE_CATEGORIES.map((cat) => {
                const isSelected = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setCategory(cat.id);
                      setTestAmount(cat.baselinePrice);
                    }}
                    className={`p-3 rounded-2xl border text-left text-xs font-heading font-bold transition cursor-pointer min-h-[48px] ${
                      isSelected
                        ? 'bg-[#121316] border-[#121316] text-white shadow-xs'
                        : 'bg-[#FAF7F0] hover:bg-[#F5F2EB] border-[#EBE5DB] text-[#141518]'
                    }`}
                  >
                    <span>{cat.name}</span>
                    {cat.id === 'cook_maid' && (
                      <span className="block text-[10px] font-mono text-[#E85A32] mt-0.5">
                        (3 jobs: Low Conf)
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Neighborhood Selector */}
          <div>
            <label className="block text-xs font-heading font-bold uppercase tracking-wider text-[#141518] mb-3">
              Select Bengaluru Neighborhood
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {NEIGHBORHOODS.map((n) => {
                const isSelected = selectedNeighborhood.id === n.id;
                return (
                  <button
                    key={n.id}
                    onClick={() => setSelectedNeighborhood(n)}
                    className={`p-3 rounded-2xl border text-left text-xs font-heading font-bold transition cursor-pointer min-h-[48px] ${
                      isSelected
                        ? 'bg-[#121316] border-[#121316] text-white shadow-xs'
                        : 'bg-[#FAF7F0] hover:bg-[#F5F2EB] border-[#EBE5DB] text-[#141518]'
                    }`}
                  >
                    <span>{n.name.split(' ')[0]}</span>
                    <span className="block text-[10px] text-[#99948B] font-mono mt-0.5">
                      {n.areaKey.replace('_', ' ')}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Live Test Slider */}
        <div className="pt-4 border-t border-[#EBE5DB]">
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-heading font-bold uppercase tracking-wider text-[#141518]">
              Interactive Test Rate Simulation
            </label>
            <span className="font-heading text-xl font-black text-[#141518] tabular-nums">
              {formatINR(testAmount)}
            </span>
          </div>
          <input
            type="range"
            min={100}
            max={2000}
            step={25}
            value={testAmount}
            onChange={(e) => setTestAmount(Number(e.target.value))}
            className="w-full accent-[#121316] cursor-pointer"
          />
        </div>
      </div>

      {/* Main Display: PriceBandGauge */}
      <PriceBandGauge
        band={band}
        currentPrice={testAmount}
        perspective="explorer"
        onPriceChange={(newPrice) => setTestAmount(newPrice)}
      />

      {/* Historical Data & Outlier Sparkline Card */}
      <div className="bg-white border border-[#EBE5DB] rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#E85A32]" />
            <h3 className="font-heading font-bold text-base text-[#141518]">
              Recent Job Telemetry &amp; Outlier Analysis
            </h3>
          </div>
          <span className="text-xs font-mono text-[#646059]">
            {recentPoints.length} Completed Jobs Sampled
          </span>
        </div>

        {/* Sparkline Visual */}
        <div className="bg-[#FAF7F0] border border-[#EBE5DB] rounded-2xl p-4">
          <div className="flex items-center justify-between text-xs text-[#646059] mb-2 font-mono">
            <span>Price Trend (Green: Valid, Red: Pruned Outlier)</span>
            <span>Historical completed jobs</span>
          </div>
          {renderSparkline()}
        </div>

        {/* Pruned Outliers List */}
        {outlierPoints.length > 0 ? (
          <div className="space-y-2">
            <h4 className="text-xs font-heading font-bold uppercase tracking-wider text-rose-600 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              {outlierPoints.length} Outlier Transaction{outlierPoints.length === 1 ? '' : 's'} Eliminated by Engine:
            </h4>
            <div className="space-y-1.5">
              {outlierPoints.map((op) => (
                <div
                  key={op.id}
                  className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs flex items-center justify-between text-rose-950 font-mono"
                >
                  <div>
                    <span className="font-bold">Job {op.id.replace(/^job_/, '')}:</span>{' '}
                    <span>{op.reason}</span>
                  </div>
                  <span className="font-bold text-rose-700">{formatINR(op.price)}</span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-950 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>All sampled jobs in this category fall strictly within legitimate market IQR fences.</span>
          </div>
        )}
      </div>
    </div>
  );
};
