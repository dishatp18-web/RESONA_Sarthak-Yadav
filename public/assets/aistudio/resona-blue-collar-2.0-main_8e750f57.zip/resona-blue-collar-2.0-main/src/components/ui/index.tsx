/**
 * FairFix ProFlow Component Suite
 * Clean, warm luminous aesthetic matching the ProFlow reference design.
 * Yellow CTA pills with black arrow badge, warm modern cards, and refined typography.
 */
import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LucideIcon, CheckCircle2, AlertTriangle, AlertOctagon, Info, ShieldCheck, X } from 'lucide-react';

/**
 * Format numbers using standard Indian currency grouping (e.g. ₹1,25,000)
 */
export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

/* 1. ArcLoader: Smooth modern spinner */
export const ArcLoader: React.FC<{ size?: 'sm' | 'md' | 'lg'; className?: string }> = ({
  size = 'md',
  className = '',
}) => {
  const dims = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-8 h-8' : 'w-5 h-5';

  return (
    <div className={`relative inline-flex items-center justify-center ${dims} ${className}`}>
      <div className="absolute inset-0 rounded-full border-2 border-neutral-300" />
      <div className="absolute inset-0 rounded-full border-2 border-t-[#121316] border-r-[#121316] border-b-transparent border-l-transparent animate-spin" />
    </div>
  );
};

/* 2. ForgeButton: Yellow ProFlow Pill & Modern Actions */
export interface ForgeButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'ghost' | 'danger' | 'dark';
  icon?: LucideIcon;
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  loading?: boolean;
  showArrowBadge?: boolean;
}

export const ForgeButton: React.FC<ForgeButtonProps> = ({
  children,
  variant = 'primary',
  icon: Icon,
  size = 'md',
  fullWidth = false,
  loading = false,
  showArrowBadge = false,
  disabled,
  className = '',
  ...props
}) => {
  const sizeClasses = {
    sm: 'py-1.5 px-3.5 text-xs rounded-full gap-1.5 min-h-[36px]',
    md: 'py-2.5 px-5 text-sm rounded-full gap-2 min-h-[44px]',
    lg: 'py-3 px-6 text-sm sm:text-base rounded-full gap-2.5 min-h-[48px]',
  }[size];

  const variantStyles = {
    primary:
      'bg-[#FFEA00] hover:bg-[#FFD600] text-[#121316] font-extrabold shadow-[0_4px_16px_rgba(255,234,0,0.35)] hover:shadow-[0_6px_22px_rgba(255,234,0,0.5)] border-none active:scale-[0.98]',
    ghost:
      'bg-white hover:bg-[#F5F2EB] text-[#141518] border border-[#EBE5DB] hover:border-[#D5CEBF] font-bold shadow-sm active:scale-[0.98]',
    dark:
      'bg-[#121316] hover:bg-[#252830] text-white border border-transparent font-bold shadow-sm active:scale-[0.98]',
    danger:
      'bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 font-bold active:scale-[0.98]',
  }[variant];

  return (
    <button
      disabled={disabled || loading}
      className={`relative inline-flex items-center justify-center font-heading tracking-normal font-bold transition-all duration-200 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed disabled:pointer-events-none ${
        fullWidth ? 'w-full' : ''
      } ${sizeClasses} ${variantStyles} ${className}`}
      {...props}
    >
      {loading ? (
        <ArcLoader size="sm" />
      ) : (
        <>
          {Icon && <Icon className={size === 'sm' ? 'w-3.5 h-3.5 shrink-0' : 'w-4 h-4 shrink-0'} />}
          <span>{children}</span>
          {showArrowBadge && (
            <span className="w-6 h-6 rounded-md bg-[#121316] text-white flex items-center justify-center text-xs font-black shrink-0 ml-1">
              ↗
            </span>
          )}
        </>
      )}
    </button>
  );
};

/* 3. HudPanel: Clean Warm Card */
export interface HudPanelProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  variant?: 'default' | 'highlight' | 'flat' | 'dark';
  selected?: boolean;
  className?: string;
}

export const HudPanel: React.FC<HudPanelProps> = ({
  children,
  variant = 'default',
  selected = false,
  className = '',
  ...props
}) => {
  const variantStyles = {
    default: 'bg-white border border-[#EBE5DB] shadow-[0_2px_12px_rgba(35,30,20,0.04)] text-[#141518]',
    highlight: 'bg-white border-[#FFEA00] ring-2 ring-[#FFEA00]/60 shadow-[0_4px_20px_rgba(255,234,0,0.2)] text-[#141518]',
    flat: 'bg-[#F5F2EB] border border-[#EBE5DB] text-[#141518]',
    dark: 'bg-[#121316] border border-[#252830] text-white shadow-xl',
  }[variant];

  const selectedRing = selected ? 'ring-2 ring-[#FFEA00] shadow-[0_4px_20px_rgba(255,234,0,0.3)]' : '';

  return (
    <div
      className={`hud-panel rounded-2xl sm:rounded-3xl p-4 sm:p-6 transition-all duration-200 ${variantStyles} ${selectedRing} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};

/* 4. Badge / Chip */
export interface BadgeProps {
  children: React.ReactNode;
  variant?: 'fair' | 'caution' | 'danger' | 'info' | 'neutral' | 'verified';
  icon?: LucideIcon;
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  icon: Icon,
  size = 'sm',
  className = '',
}) => {
  const styles = {
    fair: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    caution: 'bg-amber-50 text-amber-800 border-amber-200',
    danger: 'bg-rose-50 text-rose-800 border-rose-200',
    info: 'bg-sky-50 text-sky-800 border-sky-200',
    neutral: 'bg-[#F5F2EB] text-[#646059] border-[#EBE5DB]',
    verified: 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-xs font-bold',
  }[variant];

  const defaultIcons = {
    fair: CheckCircle2,
    caution: AlertTriangle,
    danger: AlertOctagon,
    info: Info,
    neutral: undefined,
    verified: ShieldCheck,
  };

  const DisplayIcon = Icon || defaultIcons[variant];
  const sizeStyles = size === 'sm' ? 'text-[11px] px-2.5 py-0.5' : 'text-xs px-3 py-1';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-heading font-semibold rounded-full border ${styles} ${sizeStyles} ${className}`}
    >
      {DisplayIcon && <DisplayIcon className={size === 'sm' ? 'w-3 h-3 shrink-0' : 'w-3.5 h-3.5 shrink-0'} />}
      <span>{children}</span>
    </span>
  );
};

/* 5. Tabs / SegmentedControl with Sliding Pill */
export interface TabOption {
  id: string;
  label: string;
  icon?: LucideIcon;
  badge?: string | number;
}

export interface TabsProps {
  options: TabOption[];
  activeId: string;
  onChange: (id: string) => void;
  className?: string;
}

export const Tabs: React.FC<TabsProps> = ({
  options,
  activeId,
  onChange,
  className = '',
}) => {
  const handleKeyDown = (e: React.KeyboardEvent, currentIndex: number) => {
    if (e.key === 'ArrowRight') {
      const nextIndex = (currentIndex + 1) % options.length;
      onChange(options[nextIndex].id);
    } else if (e.key === 'ArrowLeft') {
      const prevIndex = (currentIndex - 1 + options.length) % options.length;
      onChange(options[prevIndex].id);
    }
  };

  return (
    <div
      role="tablist"
      className={`inline-flex p-1 bg-[#F5F2EB] border border-[#EBE5DB] rounded-full relative ${className}`}
    >
      {options.map((opt, idx) => {
        const isActive = activeId === opt.id;
        const Icon = opt.icon;
        return (
          <button
            key={opt.id}
            role="tab"
            aria-selected={isActive}
            tabIndex={isActive ? 0 : -1}
            onClick={() => onChange(opt.id)}
            onKeyDown={(e) => handleKeyDown(e, idx)}
            className={`relative px-4 py-2 rounded-full text-xs font-heading font-bold transition-all duration-200 flex items-center gap-1.5 cursor-pointer z-10 ${
              isActive ? 'text-[#121316]' : 'text-[#646059] hover:text-[#121316]'
            }`}
          >
            {isActive && (
              <motion.div
                layoutId="activeTabPillForge"
                className="absolute inset-0 rounded-full bg-white shadow-sm border border-[#EBE5DB] -z-10"
                transition={{ type: 'spring', stiffness: 500, damping: 35 }}
              />
            )}
            {Icon && <Icon className="w-3.5 h-3.5 shrink-0" />}
            <span>{opt.label}</span>
            {opt.badge !== undefined && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ml-1 ${
                isActive ? 'bg-[#FFEA00] text-[#121316]' : 'bg-[#EBE5DB] text-[#646059]'
              }`}>
                {opt.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};

/* 6. Skeleton Loader */
export const Skeleton: React.FC<{ className?: string }> = ({ className = 'h-4 w-full' }) => {
  return (
    <div className={`animate-pulse bg-[#F5F2EB] rounded-xl ${className}`} />
  );
};

/* 7. Toast System */
export interface ToastMessage {
  id: string;
  title: string;
  message?: string;
  type?: 'fair' | 'caution' | 'danger' | 'info';
}

interface ToastContextType {
  showToast: (toast: Omit<ToastMessage, 'id'>) => void;
}

const ToastContext = React.createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = (t: Omit<ToastMessage, 'id'>) => {
    const id = `toast_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const newToast: ToastMessage = { ...t, id };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 4500);
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div
        aria-live="polite"
        className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-3"
      >
        <AnimatePresence>
          {toasts.map((toast) => {
            const borderColors = {
              fair: 'border-emerald-200 bg-white text-emerald-900',
              caution: 'border-amber-200 bg-white text-amber-900',
              danger: 'border-rose-200 bg-white text-rose-900',
              info: 'border-sky-200 bg-white text-sky-900',
            }[toast.type || 'info'];

            return (
              <motion.div
                key={toast.id}
                initial={{ opacity: 0, x: 20, scale: 0.95 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: 20, scale: 0.95 }}
                transition={{ duration: 0.2 }}
                className={`pointer-events-auto p-4 rounded-2xl border shadow-xl flex flex-col gap-0.5 ${borderColors}`}
              >
                <div className="font-heading font-bold text-xs flex items-center justify-between">
                  <span>{toast.title}</span>
                </div>
                {toast.message && (
                  <p className="text-xs text-neutral-600 font-sans leading-relaxed">{toast.message}</p>
                )}
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
};

export function useToast() {
  const ctx = React.useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}

/* 8. EmptyState */
export interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon: Icon,
  title,
  description,
  action,
}) => {
  return (
    <div className="hud-panel p-8 sm:p-12 text-center rounded-3xl border border-[#EBE5DB] flex flex-col items-center justify-center bg-white">
      <div className="w-14 h-14 rounded-2xl bg-[#FFF1EC] border border-[#E85A32]/20 flex items-center justify-center text-[#E85A32] mb-3">
        <Icon className="w-7 h-7" />
      </div>
      <h4 className="font-heading font-bold text-base text-[#141518] mb-1">{title}</h4>
      <p className="text-xs text-[#646059] max-w-sm mb-4 leading-relaxed font-sans">{description}</p>
      {action && (
        <ForgeButton variant="ghost" size="sm" onClick={action.onClick}>
          {action.label}
        </ForgeButton>
      )}
    </div>
  );
};

/* 9. StatCard with Count-Up */
export interface StatCardProps {
  label: string;
  value: number;
  prefix?: string;
  suffix?: string;
  icon?: LucideIcon;
  change?: string;
  subtext?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  prefix = '',
  suffix = '',
  icon: Icon,
  change,
  subtext,
}) => {
  const [displayValue, setDisplayValue] = useState(value);
  const prevValue = useRef(value);

  useEffect(() => {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      setDisplayValue(value);
      return;
    }

    const start = prevValue.current;
    const end = value;
    if (start === end) return;

    const duration = 650;
    const startTime = performance.now();

    const step = (now: number) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current = Math.round(start + (end - start) * ease);
      setDisplayValue(current);

      if (progress < 1) {
        requestAnimationFrame(step);
      } else {
        prevValue.current = end;
      }
    };

    requestAnimationFrame(step);
  }, [value]);

  return (
    <div className="hud-panel p-5 rounded-2xl sm:rounded-3xl border border-[#EBE5DB] bg-white flex flex-col justify-between">
      <div className="flex items-center justify-between text-xs text-[#646059] mb-2">
        <span className="font-heading uppercase tracking-wider font-bold text-[11px]">{label}</span>
        {Icon && <Icon className="w-4 h-4 text-[#E85A32]" />}
      </div>
      <div className="flex items-baseline gap-2">
        <span className="font-heading text-3xl font-extrabold text-[#E85A32] tabular-nums tracking-tight">
          {prefix}{displayValue.toLocaleString('en-IN')}{suffix}
        </span>
        {change && (
          <span className="text-[11px] font-heading font-bold text-emerald-600">{change}</span>
        )}
      </div>
      {subtext && <p className="text-[11px] text-[#646059] mt-1 font-sans">{subtext}</p>}
    </div>
  );
};

/* 10. Drawer */
export interface DrawerProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

export const Drawer: React.FC<DrawerProps> = ({ isOpen, onClose, title, children }) => {
  const drawerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-end md:items-stretch md:justify-end">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-xs"
          />
          <motion.div
            ref={drawerRef}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            transition={{ type: 'spring', damping: 30, stiffness: 350 }}
            className="relative w-full md:max-w-lg bg-white border-t md:border-t-0 md:border-l border-[#EBE5DB] p-6 shadow-2xl z-10 max-h-[85vh] md:max-h-full overflow-y-auto text-[#141518]"
          >
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#EBE5DB]">
              <h3 className="font-heading font-bold text-base text-[#141518] flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#E85A32]" />
                {title}
              </h3>
              <button
                onClick={onClose}
                className="text-[#646059] hover:text-[#141518] p-1.5 rounded-full hover:bg-[#F5F2EB] cursor-pointer"
                aria-label="Close drawer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {children}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

/* 11. Timeline */
export interface TimelineStep {
  id: string;
  title: string;
  time?: string | null;
  description?: string;
  isCompleted: boolean;
  isCurrent: boolean;
  isFailed?: boolean;
}

export const Timeline: React.FC<{ steps: TimelineStep[] }> = ({ steps }) => {
  return (
    <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#EBE5DB]">
      {steps.map((step) => {
        return (
          <div key={step.id} className="relative group">
            <div
              className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                step.isFailed
                  ? 'border-rose-500 bg-rose-100 text-rose-600'
                  : step.isCompleted
                  ? 'border-[#121316] bg-[#121316] text-white shadow-xs'
                  : step.isCurrent
                  ? 'border-[#FFEA00] bg-[#FFEA00] text-black ring-4 ring-[#FFEA00]/30 animate-pulse'
                  : 'border-[#D5CEBF] bg-white text-[#99948B]'
              }`}
            >
              {step.isCompleted ? (
                <span className="text-[10px] font-black">✓</span>
              ) : (
                <span className="w-1.5 h-1.5 rounded-full bg-current" />
              )}
            </div>

            <div className="flex items-baseline justify-between gap-2">
              <h5
                className={`font-heading text-xs font-bold ${
                  step.isCompleted || step.isCurrent ? 'text-[#141518]' : 'text-[#99948B]'
                }`}
              >
                {step.title}
              </h5>
              {step.time && (
                <span className="text-[10px] text-[#646059] font-mono">
                  {new Date(step.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              )}
            </div>
            {step.description && (
              <p className="text-[11px] text-[#646059] mt-0.5 font-sans leading-relaxed">{step.description}</p>
            )}
          </div>
        );
      })}
    </div>
  );
};
