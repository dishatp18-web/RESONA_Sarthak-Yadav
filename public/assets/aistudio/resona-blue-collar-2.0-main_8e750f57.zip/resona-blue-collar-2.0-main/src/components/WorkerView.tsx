/**
 * FairFix Worker Portal - "ProFlow Modern" Edition
 * Warm luminous atmosphere, electric-yellow CTA pills, terracotta accents,
 * base rate self-determination, document upload, and live incoming requests.
 */
import React, { useState, useEffect } from 'react';
import { useDemoUser } from '../context/DemoUserContext.js';
import { PriceBandResult } from '../types.js';
import { PriceBandGauge } from './PriceBandGauge.js';
import { NegotiationThread } from './NegotiationThread.js';
import { getCategoryLabel } from '../config.js';
import { 
  HudPanel, 
  ForgeButton, 
  Badge, 
  StatCard, 
  Drawer, 
  EmptyState, 
  formatINR 
} from './ui/index.js';
import { 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  XCircle, 
  Power, 
  Save, 
  Star, 
  Briefcase, 
  Info,
  MapPin,
  FileText,
  Handshake,
  MessageSquare,
  ArrowRight
} from 'lucide-react';

export const WorkerView: React.FC = () => {
  const { currentUser, refreshUsers } = useDemoUser();

  const [available, setAvailable] = useState<boolean>(currentUser?.available ?? true);
  const [baseRate, setBaseRate] = useState<number>(currentUser?.base_rate ?? 450);
  const [savingRate, setSavingRate] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  // Price band states for worker's primary category
  const [band, setBand] = useState<PriceBandResult | null>(null);

  // Incoming Requests & Active Jobs
  const [incomingJobs, setIncomingJobs] = useState<any[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [loadingJobs, setLoadingJobs] = useState(false);

  const primaryCategory = currentUser?.categories?.[0] || 'plumbing';

  useEffect(() => {
    if (currentUser) {
      setAvailable(currentUser.available ?? true);
      setBaseRate(currentUser.base_rate ?? 450);
    }
  }, [currentUser]);

  // Load price band for worker's category and location
  useEffect(() => {
    if (!currentUser) return;
    const fetchBand = async () => {
      try {
        const res = await fetch(
          `/api/price-band?category=${primaryCategory}&lat=${currentUser.lat}&lng=${currentUser.lng}&price=${baseRate}&perspective=worker`
        );
        if (!res.ok) throw new Error('Failed to load band');
        const data = await res.json();
        setBand(data.band);
      } catch (err) {
        console.error('Error fetching worker band:', err);
      }
    };

    fetchBand();
  }, [primaryCategory, currentUser, baseRate]);

  // Fetch incoming & active jobs for this worker (with 3s polling)
  const fetchWorkerJobs = async () => {
    if (!currentUser) return;
    try {
      const res = await fetch(`/api/jobs?workerId=${currentUser.id}&incoming=true`);
      if (!res.ok) return;
      const data = await res.json();
      setIncomingJobs(data);
    } catch (err) {
      console.error('Error fetching worker jobs:', err);
    }
  };

  useEffect(() => {
    fetchWorkerJobs();
    const interval = setInterval(fetchWorkerJobs, 3000);
    return () => clearInterval(interval);
  }, [currentUser]);

  // Handle Availability Toggle
  const handleToggleAvailability = async () => {
    if (!currentUser) return;
    const newStatus = !available;
    setAvailable(newStatus);

    try {
      const res = await fetch(`/api/workers/${currentUser.id}/availability`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ available: newStatus }),
      });
      if (!res.ok) throw new Error('Failed to toggle availability');
      await refreshUsers();
    } catch (err) {
      alert('Error updating availability: ' + (err as Error).message);
      setAvailable(!newStatus);
    }
  };

  // Handle Save Base Rate
  const handleSaveRate = async () => {
    if (!currentUser) return;
    setSavingRate(true);
    setSaveMessage(null);
    try {
      const res = await fetch(`/api/workers/${currentUser.id}/rate`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ base_rate: baseRate }),
      });
      if (!res.ok) throw new Error('Failed to save rate');
      setSaveMessage('Base rate saved! Market band comparison updated.');
      await refreshUsers();
      setTimeout(() => setSaveMessage(null), 3500);
    } catch (err) {
      alert('Error saving rate: ' + (err as Error).message);
    } finally {
      setSavingRate(false);
    }
  };

  // Document Upload State
  const [uploadingDoc, setUploadingDoc] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccess, setUploadSuccess] = useState<string | null>(null);
  const [showUploadForm, setShowUploadForm] = useState(false);

  const handleDocumentUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser) return;
    setUploadError(null);
    setUploadSuccess(null);

    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Document exceeds maximum size of 5 MB.');
      return;
    }

    const allowed = ['image/jpeg', 'image/png', 'application/pdf'];
    if (!allowed.includes(file.type)) {
      setUploadError('Only JPG, PNG, and PDF formats are accepted.');
      return;
    }

    setUploadingDoc(true);
    try {
      const formData = new FormData();
      formData.append('document', file);
      const res = await fetch(`/api/workers/${currentUser.id}/verification-document`, {
        method: 'POST',
        headers: {
          'x-demo-role': 'worker',
          'x-demo-user-id': currentUser.id,
        },
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to upload document');
      setUploadSuccess('Document submitted! Awaiting manual admin review.');
      setShowUploadForm(false);
      await refreshUsers();
    } catch (err) {
      setUploadError((err as Error).message);
    } finally {
      setUploadingDoc(false);
    }
  };

  const verificationBadge = () => {
    const status = currentUser?.verification_status || 'unverified';

    return (
      <div className="space-y-3">
        {/* Moderation Warnings */}
        {currentUser?.is_suspended && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs space-y-1 text-rose-900">
            <div className="flex items-center gap-2 font-heading font-bold">
              <XCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>Account Suspended by Operations</span>
            </div>
            <p className="text-[11px] text-rose-700 font-sans">
              Your profile has been suspended by administration. You are temporarily hidden from customer searches.
            </p>
          </div>
        )}

        {currentUser?.is_flagged && !currentUser?.is_suspended && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs space-y-1 text-amber-900">
            <div className="flex items-center gap-2 font-heading font-bold">
              <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
              <span>Under Review Chip Active</span>
            </div>
            <p className="text-[11px] text-amber-700 font-sans">
              Account auto-flagged following 3 distinct customer reports. Your profile ranks last in matching until reviewed by an administrator.
            </p>
          </div>
        )}

        {/* Verification Status Card */}
        {status === 'verified' && (
          <div className="flex items-center justify-between p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 text-xs">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
              <div>
                <p className="font-heading font-extrabold text-[#141518]">Verified Worker Badge Active</p>
                <p className="text-[11px] text-emerald-700 font-sans">
                  Approved credential. You receive top priority matching radar boost in customer searches.
                </p>
              </div>
            </div>
            <Badge variant="verified" size="sm">
              Verified
            </Badge>
          </div>
        )}

        {status === 'pending' && (
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-amber-950 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 shrink-0 text-amber-600" />
                <p className="font-heading font-extrabold text-[#141518]">Verification In Review</p>
              </div>
              <Badge variant="caution" size="sm">
                Pending Review
              </Badge>
            </div>
            <p className="text-[11px] text-amber-800 font-sans">
              Trade document submitted and securely stored. Awaiting manual admin review.
            </p>
          </div>
        )}

        {status === 'rejected' && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs space-y-2 text-rose-950">
            <div className="flex items-center justify-between text-rose-900">
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 shrink-0 text-rose-600" />
                <p className="font-heading font-extrabold text-[#141518]">Verification Rejected</p>
              </div>
              <Badge variant="danger" size="sm">
                Action Required
              </Badge>
            </div>
            {currentUser?.verification_reject_reason && (
              <div className="p-3 bg-white rounded-xl border border-rose-200 text-xs text-rose-950">
                <strong className="text-rose-600">Admin Reason:</strong> {currentUser.verification_reject_reason}
              </div>
            )}
            <button
              onClick={() => setShowUploadForm(true)}
              className="px-4 py-2 rounded-full bg-[#121316] text-white font-heading font-bold text-xs hover:bg-black cursor-pointer"
            >
              Upload Corrected Document
            </button>
          </div>
        )}

        {status === 'unverified' && (
          <div className="p-4 bg-[#FAF7F0] border border-[#EBE5DB] rounded-2xl text-xs space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
                <p className="font-heading font-extrabold text-[#141518]">Unverified Profile</p>
              </div>
              <Badge variant="neutral" size="sm">
                Unverified
              </Badge>
            </div>
            <p className="text-xs text-[#646059] font-sans">
              Upload your trade certificate or government ID to earn the Verified badge and unlock priority customer matching.
            </p>
            <button
              onClick={() => setShowUploadForm(true)}
              className="pro-pill-yellow !py-2 !px-4 !text-xs"
            >
              <FileText className="w-3.5 h-3.5 mr-1" />
              <span>Upload Verification Document</span>
              <span className="pro-arrow-badge !w-4 !h-4 !text-[9px]">↗</span>
            </button>
          </div>
        )}

        {/* Upload Document Modal */}
        {showUploadForm && (
          <div className="p-5 bg-white border border-[#EBE5DB] rounded-2xl space-y-3 shadow-md">
            <div className="flex items-center justify-between">
              <span className="font-heading font-extrabold text-xs text-[#141518] flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-[#E85A32]" />
                Upload Trade Credential or ID
              </span>
              <button
                onClick={() => setShowUploadForm(false)}
                className="text-xs text-[#646059] hover:text-[#141518]"
              >
                Close
              </button>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs space-y-1">
              <p className="font-bold text-amber-900">
                Security Notice: Mask the first 8 digits of any ID number before uploading.
              </p>
              <p className="text-[11px] text-amber-800">
                Never upload raw full ID numbers. Allowed formats: JPG, PNG, or PDF (max 5 MB).
              </p>
            </div>

            <input
              type="file"
              accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf"
              onChange={handleDocumentUpload}
              disabled={uploadingDoc}
              className="block w-full text-xs text-[#646059] file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-heading file:font-bold file:bg-[#121316] file:text-white hover:file:bg-black file:cursor-pointer cursor-pointer"
            />

            {uploadingDoc && (
              <p className="text-xs text-emerald-700 animate-pulse font-mono">
                Uploading document &amp; verifying mime-type...
              </p>
            )}

            {uploadError && (
              <p className="text-xs text-rose-600 font-mono">{uploadError}</p>
            )}

            {uploadSuccess && (
              <p className="text-xs text-emerald-700 font-mono">{uploadSuccess}</p>
            )}
          </div>
        )}
      </div>
    );
  };

  const activeNegotiations = incomingJobs.filter((j) =>
    ['requested', 'negotiating', 'accepted', 'in_progress', 'completed', 'rated'].includes(j.status)
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Top Banner Card */}
      <div className="bg-white border border-[#EBE5DB] rounded-3xl p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#121316] text-[#FFEA00] flex items-center justify-center font-heading font-extrabold text-2xl shrink-0 shadow-sm">
            {currentUser?.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-heading text-2xl font-extrabold text-[#141518]">
                {currentUser?.name}
              </h1>
              <span className="pro-eyebrow !text-[10px]">• WORKER PORTAL</span>
            </div>
            <div className="flex flex-wrap items-center gap-2.5 text-xs text-[#646059] mt-1.5 font-sans">
              <span className="flex items-center gap-1 text-[#141518] font-bold">
                <Star className="w-4 h-4 fill-[#FFEA00] text-[#FFEA00]" />
                {currentUser?.rating_avg || 0}
                <span className="text-[#99948B] font-normal">({currentUser?.rating_count || 0} ratings)</span>
              </span>
              <span>&bull;</span>
              <span className="text-[#141518] font-semibold">{currentUser?.jobs_completed || 0} jobs completed</span>
              <Badge variant="neutral" size="sm">
                Verified Local Pro
              </Badge>
            </div>
          </div>
        </div>

        {/* Availability Toggle */}
        <div className="flex items-center gap-4 bg-[#FAF7F0] p-3 rounded-2xl border border-[#EBE5DB]">
          <div className="text-right">
            <span className="text-xs font-heading font-bold block text-[#141518]">
              {available ? 'Online (Accepting Jobs)' : 'Offline (Paused)'}
            </span>
            <span className="text-[11px] text-[#646059] font-sans">
              {available ? 'Visible in customer radar' : 'Hidden from searches'}
            </span>
          </div>

          <button
            type="button"
            onClick={handleToggleAvailability}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-200 shadow-xs cursor-pointer ${
              available
                ? 'bg-emerald-500 text-white shadow-md'
                : 'bg-neutral-200 text-neutral-500 hover:bg-neutral-300'
            }`}
            title="Toggle Availability"
            aria-label="Toggle Availability"
          >
            <Power className="w-5 h-5 font-bold" />
          </button>
        </div>
      </div>

      {/* INCOMING SERVICE REQUESTS & NEGOTIATION CONSOLE */}
      <div className="bg-white border border-[#EBE5DB] rounded-3xl p-6 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Handshake className="w-5 h-5 text-[#E85A32]" />
            <h2 className="font-heading text-lg font-extrabold text-[#141518]">
              Incoming Service Requests &amp; Negotiations ({activeNegotiations.length})
            </h2>
          </div>
          <span className="text-xs font-mono text-emerald-700 font-bold">
            Live 3s Polling
          </span>
        </div>

        {activeNegotiations.length === 0 ? (
          <EmptyState
            icon={Handshake}
            title="No pending requests in your area"
            description="When customers submit requests matching your trade within your radius, they will appear here with live negotiation controls."
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {activeNegotiations.map((job) => {
              const latestOffer = job.latest_offer;
              const isAccepted = ['accepted', 'in_progress', 'completed', 'rated'].includes(job.status);
              const isWaitingWorker = latestOffer?.from_role === 'customer';

              return (
                <div
                  key={job.id}
                  className={`p-5 rounded-2xl border transition-all ${
                    isAccepted
                      ? 'bg-emerald-50/60 border-emerald-200'
                      : isWaitingWorker
                      ? 'bg-[#FAF7F0] border-[#121316] ring-2 ring-[#FFEA00] shadow-sm'
                      : 'bg-white border-[#EBE5DB]'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-heading font-extrabold text-sm text-[#141518]">
                          Job {job.id.replace(/^job_/, '')}
                        </span>
                        <Badge
                          variant={isAccepted ? 'fair' : isWaitingWorker ? 'caution' : 'neutral'}
                          size="sm"
                        >
                          {job.status.toUpperCase()}
                        </Badge>
                      </div>
                      <p className="text-xs text-[#141518] mt-1 font-sans">{job.description}</p>
                      <p className="text-[11px] text-[#646059] mt-0.5">
                        Customer: <strong className="text-[#141518]">{job.customer_name}</strong> &bull; {getCategoryLabel(job.category)}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] uppercase font-heading font-bold text-[#99948B] block">
                        {isAccepted ? 'Agreed Price' : 'Offered Price'}
                      </span>
                      <span className="font-heading font-black text-lg text-[#141518] tabular-nums">
                        {formatINR(job.agreed_price || latestOffer?.amount || job.offered_price)}
                      </span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-[#EBE5DB] flex items-center justify-between text-xs">
                    <span className="font-mono text-[11px] text-[#E85A32] font-semibold">
                      {job.status === 'in_progress'
                        ? 'Service in progress'
                        : job.status === 'completed' || job.status === 'rated'
                        ? 'Job concluded'
                        : isAccepted
                        ? 'Contact unmasked'
                        : isWaitingWorker
                        ? 'Your turn to respond'
                        : 'Waiting for customer'}
                    </span>

                    <ForgeButton
                      variant={isWaitingWorker || job.status === 'accepted' || job.status === 'in_progress' ? 'primary' : 'ghost'}
                      size="sm"
                      icon={MessageSquare}
                      onClick={() => setSelectedJobId(job.id)}
                    >
                      {job.status === 'accepted'
                        ? 'Start Job'
                        : job.status === 'in_progress'
                        ? 'Complete Job'
                        : job.status === 'completed' || job.status === 'rated'
                        ? 'View Summary'
                        : isWaitingWorker
                        ? 'Respond'
                        : 'View Negotiation'}
                    </ForgeButton>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Main Grid: Rate Setup & Gauge */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Rate Setup */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-[#EBE5DB] rounded-3xl p-6 shadow-xs space-y-4">
            <div>
              <span className="pro-eyebrow">• RATE SELF-DETERMINATION</span>
              <h2 className="font-heading text-lg font-extrabold text-[#141518] mt-1">
                Set Your Operational Base Rate
              </h2>
              <p className="text-xs text-[#646059] mt-1 leading-relaxed font-sans">
                You freely set your own rates. The live band provides market transparency against real completed jobs in your area.
              </p>
            </div>

            {verificationBadge()}

            {/* Rate Input */}
            <div className="space-y-3 pt-2">
              <label className="block text-xs font-heading font-bold uppercase tracking-wider text-[#141518]">
                Base Rate (₹ INR per job)
              </label>

              <div className="flex items-center gap-3">
                <div className="relative flex-1">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-heading font-bold text-[#99948B] text-lg">
                    ₹
                  </span>
                  <input
                    type="number"
                    min={100}
                    step={25}
                    value={baseRate}
                    onChange={(e) => setBaseRate(Number(e.target.value))}
                    className="w-full bg-[#FAF7F0] border border-[#EBE5DB] rounded-2xl pl-9 pr-4 py-2.5 font-heading text-xl font-black text-[#141518] focus:outline-none focus:border-[#121316] tabular-nums"
                  />
                </div>

                <ForgeButton
                  size="md"
                  onClick={handleSaveRate}
                  disabled={savingRate}
                  loading={savingRate}
                  icon={Save}
                >
                  {savingRate ? 'Saving...' : 'Update Rate'}
                </ForgeButton>
              </div>

              {saveMessage && (
                <p className="text-xs text-emerald-700 font-heading font-bold">{saveMessage}</p>
              )}
            </div>

            {/* Operational Profile Details */}
            <div className="pt-4 border-t border-[#EBE5DB] space-y-2 text-xs">
              <h4 className="font-heading font-bold text-[#141518]">Operational Profile</h4>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-[#FAF7F0] rounded-xl border border-[#EBE5DB]">
                  <span className="block text-[#646059] font-medium font-sans text-[11px]">Primary Trade</span>
                  <span className="text-[#141518] font-heading font-bold">{getCategoryLabel(primaryCategory)}</span>
                </div>
                <div className="p-3 bg-[#FAF7F0] rounded-xl border border-[#EBE5DB]">
                  <span className="block text-[#646059] font-medium font-sans text-[11px]">Service Radius</span>
                  <span className="text-[#141518] font-bold font-mono">{currentUser?.radius_km || 5} km</span>
                </div>
                <div className="p-3 bg-[#FAF7F0] rounded-xl border border-[#EBE5DB]">
                  <span className="block text-[#646059] font-medium font-sans text-[11px]">Home Location</span>
                  <span className="text-[#141518] font-bold font-mono">
                    {currentUser?.lat.toFixed(3)}, {currentUser?.lng.toFixed(3)}
                  </span>
                </div>
                <div className="p-3 bg-[#FAF7F0] rounded-xl border border-[#EBE5DB]">
                  <span className="block text-[#646059] font-medium font-sans text-[11px]">Phone Number</span>
                  <span className="text-[#141518] font-mono">{currentUser?.phone}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: PriceBandGauge with Worker Perspective */}
        <div className="lg:col-span-5 space-y-5">
          <PriceBandGauge
            band={band}
            currentPrice={baseRate}
            perspective="worker"
            onPriceChange={(newPrice) => setBaseRate(newPrice)}
          />

          <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 shadow-xs space-y-3 text-xs text-[#646059]">
            <h4 className="font-heading font-bold text-[#141518] text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Info className="w-4 h-4 text-[#E85A32]" />
              Fair-Price Principles for Workers
            </h4>
            <p className="text-[11px] leading-relaxed font-sans">
              FairFix does not impose artificial rate caps on workers. If your rate falls outside the fair band, customers receive a non-blocking informational chip and can counter-offer freely during negotiation.
            </p>
          </div>
        </div>
      </div>

      {/* Negotiation Thread Drawer */}
      <Drawer
        isOpen={Boolean(selectedJobId)}
        onClose={() => setSelectedJobId(null)}
        title="Job Negotiation Console"
      >
        {selectedJobId && (
          <NegotiationThread
            jobId={selectedJobId}
            onJobUpdated={fetchWorkerJobs}
            onClose={() => setSelectedJobId(null)}
          />
        )}
      </Drawer>
    </div>
  );
};
