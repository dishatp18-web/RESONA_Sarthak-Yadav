/**
 * FairFix Top Navigation Bar - "ProFlow Modern" Edition
 * Matching the reference design: brand badge, clean center links,
 * orange phone helpline, black "Get a Quote" pill, and demo user switcher.
 */
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useDemoUser } from '../context/DemoUserContext.js';
import { 
  ShieldCheck, 
  User as UserIcon, 
  Wrench, 
  TrendingUp, 
  Clock, 
  RotateCcw, 
  MoreVertical, 
  Eye, 
  EyeOff, 
  Cpu, 
  FlaskConical, 
  PhoneCall, 
  ChevronDown 
} from 'lucide-react';
import { Badge } from './ui/index.js';

export type TabType = 'customer' | 'worker' | 'admin' | 'explorer' | 'dispatch' | 'lab';

interface NavbarProps {
  currentTab: TabType;
  setCurrentTab: (tab: TabType) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, setCurrentTab }) => {
  const { 
    users, 
    currentUser, 
    currentRole, 
    switchRole, 
    selectUser, 
    resetDatabase, 
    loading,
    hideDemoControls,
    toggleHideDemoControls
  } = useDemoUser();
  const [showOverflow, setShowOverflow] = useState(false);

  const handleRoleTabChange = (role: 'customer' | 'worker' | 'admin') => {
    switchRole(role);
    setCurrentTab(role);
  };

  const filteredUsers = users.filter((u) => u.role === currentRole);

  const navItems = [
    { id: 'customer', label: 'Services', icon: UserIcon, onClick: () => handleRoleTabChange('customer') },
    { id: 'worker', label: 'Worker Portal', icon: Wrench, onClick: () => handleRoleTabChange('worker') },
    { id: 'explorer', label: 'Fair Band', icon: TrendingUp, onClick: () => setCurrentTab('explorer') },
    { id: 'dispatch', label: 'QUBO Dispatch', icon: Cpu, onClick: () => setCurrentTab('dispatch') },
    { id: 'lab', label: 'Concept Lab', icon: FlaskConical, onClick: () => setCurrentTab('lab') },
    { id: 'admin', label: 'Admin', icon: ShieldCheck, onClick: () => { switchRole('admin'); setCurrentTab('admin'); } },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/90 border-b border-[#EBE5DB] text-[#141518] backdrop-blur-md transition-all">
      {/* Top Subtle Info Strip */}
      <div className="bg-[#FAF7F0] border-b border-[#EBE5DB]/60 px-3 sm:px-6 py-1 text-[11px] flex items-center justify-between text-[#646059]">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-[#E85A32]" />
          <span className="font-heading font-semibold text-[#141518]">Hyperlocal Verified Blue-Collar Services</span>
          <span className="hidden md:inline font-sans text-[#646059]">
            &bull; Live 25th-75th Percentile Fair-Price Band &bull; 0% Platform Price Gouging
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[10px] font-mono text-[#646059]">
            Bengaluru Market Pilot &bull; Cash on Completion
          </span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
        {/* Brand: ProFlow style black badge with logo mark */}
        <div 
          className="flex items-center gap-2.5 cursor-pointer shrink-0 select-none" 
          onClick={() => {
            switchRole('customer');
            setCurrentTab('customer');
          }}
        >
          <div className="w-9 h-9 rounded-xl bg-[#121316] flex items-center justify-center text-[#FFEA00] shadow-sm font-heading font-black text-lg">
            <span className="text-sm">⚡</span>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <span className="font-heading font-extrabold text-lg sm:text-xl tracking-tight text-[#141518]">
                Fair<span className="text-[#E85A32]">Fix</span>
              </span>
              <span className="text-[9px] uppercase font-heading font-bold tracking-wider px-2 py-0.5 rounded-full bg-[#FFF1EC] text-[#E85A32] border border-[#E85A32]/20 hidden xs:inline-block">
                Live Band
              </span>
            </div>
          </div>
        </div>

        {/* Center: Clean Modern Navigation Pill */}
        <nav aria-label="Main Navigation" className="hidden lg:flex items-center gap-1 bg-[#F5F2EB] p-1 rounded-full border border-[#EBE5DB]">
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={item.onClick}
                className={`relative px-3.5 py-1.5 rounded-full text-xs font-heading font-bold transition-all duration-200 cursor-pointer ${
                  isActive ? 'text-[#121316]' : 'text-[#646059] hover:text-[#121316]'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="activeRolePillForge"
                    className="absolute inset-0 rounded-full bg-white shadow-xs border border-[#EBE5DB] -z-10"
                    transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                  />
                )}
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Section: Helpline, Get a Quote CTA & User Switcher */}
        <div className="flex items-center gap-3">
          {/* ProFlow Style Helpline */}
          <a 
            href="tel:5551234567" 
            className="hidden sm:flex items-center gap-1.5 text-xs font-heading font-bold text-[#E85A32] hover:text-[#D44720] transition px-2"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>(555) 123-4567</span>
          </a>

          {/* "Get a Quote" Black Pill Button (Switches to Customer booking) */}
          <button
            onClick={() => {
              handleRoleTabChange('customer');
            }}
            className="hidden md:inline-flex items-center justify-center font-heading font-bold text-xs bg-[#121316] hover:bg-[#252830] text-white px-4 py-2 rounded-full transition shadow-sm cursor-pointer"
          >
            Get a Quote
          </button>

          {/* Active Demo User Selector */}
          <div className="flex items-center gap-2 bg-[#F5F2EB] border border-[#EBE5DB] rounded-full px-2.5 py-1 text-xs">
            {/* Initials Avatar */}
            <div className="w-6 h-6 rounded-full bg-[#121316] text-[#FFEA00] flex items-center justify-center font-heading font-bold text-[11px] shrink-0">
              {currentUser?.name.charAt(0)}
            </div>

            <div className="flex items-center">
              <select
                aria-label="Select active demo user"
                value={currentUser?.id || ''}
                onChange={(e) => selectUser(e.target.value)}
                className="bg-transparent font-heading font-bold text-[#141518] outline-none cursor-pointer text-xs pr-1 max-w-28 sm:max-w-32 truncate"
              >
                {filteredUsers.map((u) => (
                  <option key={u.id} value={u.id} className="bg-white text-[#141518]">
                    {u.name} {u.role === 'worker' ? `(${u.categories?.[0] || 'Worker'})` : ''}
                  </option>
                ))}
              </select>
            </div>

            {currentUser?.role === 'worker' && (
              <span className="hidden xl:inline">
                {currentUser.verification_status === 'verified' ? (
                  <Badge variant="verified" size="sm">
                    Verified
                  </Badge>
                ) : (
                  <Badge variant="caution" size="sm" icon={Clock}>
                    {currentUser.verification_status}
                  </Badge>
                )}
              </span>
            )}
          </div>

          {/* Overflow Menu Button */}
          <div className="relative">
            <button
              onClick={() => setShowOverflow(!showOverflow)}
              className="p-2 rounded-full bg-[#F5F2EB] hover:bg-[#EBE5DB] border border-[#EBE5DB] text-[#646059] hover:text-[#141518] transition cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
              title="More demo options"
              aria-label="More demo options"
            >
              <MoreVertical className="w-4 h-4" />
            </button>

            <AnimatePresence>
              {showOverflow && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: -5 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -5 }}
                  className="absolute right-0 mt-2 w-56 bg-white border border-[#EBE5DB] rounded-2xl p-2 shadow-2xl z-50 text-xs"
                >
                  {/* Mobile Navigation Links */}
                  <div className="lg:hidden pb-2 mb-2 border-b border-[#EBE5DB] space-y-1">
                    <p className="px-3 py-1 text-[10px] font-heading font-bold text-[#99948B] uppercase tracking-wider">
                      Switch Views
                    </p>
                    {navItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => {
                          setShowOverflow(false);
                          item.onClick();
                        }}
                        className="w-full flex items-center gap-2 px-3 py-1.5 rounded-xl text-left text-[#141518] hover:bg-[#F5F2EB] font-heading font-semibold"
                      >
                        <item.icon className="w-3.5 h-3.5 text-[#E85A32]" />
                        <span>{item.label}</span>
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => {
                      setShowOverflow(false);
                      if (window.confirm('Reset database to clean 12 workers, 8 customers, and 64 completed jobs?')) {
                        resetDatabase();
                      }
                    }}
                    disabled={loading}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-left text-[#141518] hover:bg-[#F5F2EB] transition cursor-pointer font-heading font-semibold"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Reset Seed Data</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowOverflow(false);
                      setCurrentTab('explorer');
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-left text-[#141518] hover:bg-[#F5F2EB] transition cursor-pointer font-heading font-semibold"
                  >
                    <TrendingUp className="w-3.5 h-3.5 text-[#E85A32]" />
                    <span>Fair-Price Monitor</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowOverflow(false);
                      toggleHideDemoControls();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-left text-[#141518] hover:bg-[#F5F2EB] transition cursor-pointer font-heading font-semibold border-t border-[#EBE5DB] mt-1 pt-2"
                  >
                    {hideDemoControls ? (
                      <>
                        <Eye className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Show demo controls</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-3.5 h-3.5 text-[#646059]" />
                        <span>Hide demo controls</span>
                      </>
                    )}
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </header>
  );
};
