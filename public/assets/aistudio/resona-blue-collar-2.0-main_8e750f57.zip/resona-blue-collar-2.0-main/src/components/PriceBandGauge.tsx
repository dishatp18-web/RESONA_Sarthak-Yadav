/**
 * PriceBandGauge: ProFlow Edition
 * Modern clean card styling, warm borders, clear typography,
 * interactive horizontal track, and collapsible IQR math explanation.
 */
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PriceBandResult } from '../types.js';
import { getCategoryLabel } from '../config.js';
import { Badge, formatINR } from './ui/index.js';
import { 
  TrendingUp, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  ChevronDown, 
  ChevronUp, 
  ArrowUp,
  ArrowDown
} from 'lucide-react';

export interface PriceBandGaugeProps {
  band: PriceBandResult | null;
  value?: number;
  currentPrice?: number;
  perspective?: 'customer' | 'worker' | 'explorer';
  category?: string;
  areaKey?: string;
  onChange?: (price: number) => void;
  onPriceChange?: (price: number) => void;
  compact?: boolean;
}

export const PriceBandGauge: React.FC<PriceBandGaugeProps> = ({
  band,
  value,
  currentPrice: legacyCurrentPrice,
  perspective = 'customer',
  onChange,
  onPriceChange,
  compact = false,
}) => {
  const effectivePrice = value !== undefined ? value : legacyCurrentPrice !== undefined ? legacyCurrentPrice : 450;
  const triggerChange = onChange || onPriceChange;

  const [showExplanation, setShowExplanation] = useState(false);
  const [justUpdated, setJustUpdated] = useState(false);
  const [delta, setDelta] = useState<number | null>(null);
  const prevTypicalRef = useRef<number | null>(null);

  // Monitor for band recomputations and show subtle pulse & delta badge
  useEffect(() => {
    if (!band) return;

    if (prevTypicalRef.current !== null && prevTypicalRef.current !== band.typical) {
      const diff = band.typical - prevTypicalRef.current;
      setDelta(diff);
      setJustUpdated(true);
      const timer = setTimeout(() => setJustUpdated(false), 5000);
      return () => clearTimeout(timer);
    }
    prevTypicalRef.current = band.typical;
  }, [band]);

  if (!band) {
    return (
      <div className="bg-white border border-[#EBE5DB] rounded-3xl p-6 animate-pulse text-xs text-[#646059]">
        Calculating live market fair-price band from nearby jobs...
      </div>
    );
  }

  // Calculate geometric scale range
  const gaugeMin = Math.max(0, Math.round(band.low * 0.7));
  const gaugeMax = Math.round(band.high * 1.3);
  const gaugeRange = gaugeMax - gaugeMin || 1;

  // Percentage positions
  const lowPct = Math.max(0, Math.min(100, ((band.low - gaugeMin) / gaugeRange) * 100));
  const highPct = Math.max(0, Math.min(100, ((band.high - gaugeMin) / gaugeRange) * 100));
  const typicalPct = Math.max(0, Math.min(100, ((band.typical - gaugeMin) / gaugeRange) * 100));
  const currentPct = Math.max(0, Math.min(100, ((effectivePrice - gaugeMin) / gaugeRange) * 100));

  // Determine current position status
  let status: 'below' | 'fair' | 'above' = 'fair';
  let statusLabel = 'In fair band';
  let statusColor = '#059669'; // Emerald

  if (effectivePrice < band.low) {
    status = 'below';
    statusLabel = 'Below band';
    statusColor = '#D97706'; // Amber
  } else if (effectivePrice > band.high) {
    status = 'above';
    statusLabel = 'Above band';
    statusColor = '#D97706'; // Amber
  }

  // Handle keyboard nudging
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!triggerChange) return;
    if (e.key === 'ArrowRight' || e.key === 'ArrowUp') {
      e.preventDefault();
      triggerChange(effectivePrice + 25);
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowDown') {
      e.preventDefault();
      triggerChange(Math.max(50, effectivePrice - 25));
    }
  };

  // Role-Aware copy
  const perspectiveHeader =
    perspective === 'worker'
      ? 'Your Rate vs. Completed Local Jobs'
      : perspective === 'explorer'
      ? 'Live Market Price Band'
      : 'Typical Price Near You';

  const perspectiveHelper =
    perspective === 'worker'
      ? status === 'fair'
        ? 'Your rate matches the typical market range for completed jobs nearby.'
        : status === 'above'
        ? 'Your rate is above the 75th percentile of completed jobs nearby.'
        : 'Your rate is below what customers typically pay in this neighborhood.'
      : status === 'fair'
      ? 'Offers inside the band are easier to compare and attract prompt worker responses.'
      : status === 'above'
      ? 'Your price is above the fair-price band. You may be offering more than the typical local range.'
      : 'Your price is below the fair-price band. Workers may counter-offer or take longer to respond.';

  const confidenceBadge = () => {
    switch (band.confidence) {
      case 'high':
        return (
          <Badge variant="fair" icon={CheckCircle2}>
            High Confidence ({band.jobCount} jobs)
          </Badge>
        );
      case 'low (few jobs)':
        return (
          <Badge variant="caution" icon={AlertTriangle}>
            Low ({band.jobCount} jobs)
          </Badge>
        );
      case 'estimate':
      default:
        return (
          <Badge variant="caution" icon={Info}>
            Baseline Estimate
          </Badge>
        );
    }
  };

  // Distance between user's typed price and typical median
  const priceDiffFromTypical = effectivePrice - band.typical;

  return (
    <div className="bg-white border border-[#EBE5DB] rounded-3xl p-5 sm:p-6 shadow-xs relative space-y-4">
      {/* Header Row */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#FFF1EC] text-[#E85A32] flex items-center justify-center">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h4 className="font-heading font-extrabold text-sm text-[#141518]">
                {perspectiveHeader}
              </h4>
              <Badge variant="neutral" size="sm">
                Live Telemetry
              </Badge>
            </div>
            <p className="text-[11px] text-[#646059] font-sans capitalize mt-0.5">
              {getCategoryLabel(band.category)} &bull; Bengaluru
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {priceDiffFromTypical < 0 ? (
            <span className="inline-flex items-center text-[11px] font-heading font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
              <ArrowDown className="w-3 h-3 mr-0.5" />
              {formatINR(Math.abs(priceDiffFromTypical))} below median
            </span>
          ) : priceDiffFromTypical > 0 ? (
            <span className="inline-flex items-center text-[11px] font-heading font-bold px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
              <ArrowUp className="w-3 h-3 mr-0.5" />
              {formatINR(priceDiffFromTypical)} above median
            </span>
          ) : (
            <span className="inline-flex items-center text-[11px] font-heading font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
              <CheckCircle2 className="w-3 h-3 mr-0.5" />
              Matches median
            </span>
          )}
          {confidenceBadge()}
        </div>
      </div>

      {/* Hero Numbers Container */}
      <div className="flex items-baseline justify-between bg-[#FAF7F0] border border-[#EBE5DB] rounded-2xl p-4">
        <div>
          <span className="text-[10px] uppercase tracking-wider font-heading text-[#646059] block font-bold">
            Fair Market Band (25th – 75th %ile)
          </span>
          <span className="font-heading text-xl sm:text-2xl font-black text-[#141518] tracking-tight tabular-nums">
            {formatINR(band.low)} – {formatINR(band.high)}
          </span>
        </div>
        <div className="text-right">
          <span className="text-[10px] uppercase tracking-wider font-heading text-[#E85A32] font-bold block">
            Neighborhood Median
          </span>
          <span className="font-heading text-lg sm:text-xl font-extrabold text-[#E85A32] tabular-nums">
            {formatINR(band.typical)}
          </span>
        </div>
      </div>

      {/* Interactive Horizontal Track */}
      {(() => {
        const isCloseToTypical = Math.abs(currentPct - typicalPct) < 10;
        return (
          <div
            className="relative pt-8 pb-9 px-2 my-1 outline-none"
            tabIndex={0}
            role="slider"
            aria-label="Your offered price on live band"
            aria-valuemin={gaugeMin}
            aria-valuemax={gaugeMax}
            aria-valuenow={effectivePrice}
            aria-valuetext={`${formatINR(effectivePrice)}: ${statusLabel}`}
            onKeyDown={handleKeyDown}
          >
            {/* Base Bar */}
            <div className="h-3 w-full bg-[#F5F2EB] border border-[#EBE5DB] rounded-full overflow-hidden relative flex">
              {/* Below Zone */}
              <div
                style={{ width: `${lowPct}%` }}
                className="h-full bg-amber-100/60 border-r border-amber-200 transition-all duration-500"
                title="Below fair band"
              />

              {/* Fair Zone (Vibrant Emerald / Teal Bar) */}
              <div
                style={{ width: `${highPct - lowPct}%` }}
                className="h-full bg-emerald-500 shadow-xs relative transition-all duration-500"
                title="Fair market band"
              />

              {/* Above Zone */}
              <div
                style={{ width: `${100 - highPct}%` }}
                className="h-full bg-amber-100/60 border-l border-amber-200 transition-all duration-500"
                title="Above fair band"
              />
            </div>

            {/* Median Tick with Label Above */}
            <div
              style={{ left: `${typicalPct}%` }}
              className="absolute top-2 bottom-5 w-0.5 bg-[#121316] -translate-x-1/2 pointer-events-none transition-all duration-500 z-10"
            >
              <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-[#121316] text-white text-[10px] font-heading font-bold px-2 py-0.5 rounded-full whitespace-nowrap shadow-sm">
                Median: {formatINR(band.typical)}
              </div>
            </div>

            {/* Low & High Markers */}
            <div
              style={{ left: `${lowPct}%` }}
              className="absolute bottom-0 -translate-x-1/2 text-[10px] font-mono text-[#646059]"
            >
              {formatINR(band.low)}
            </div>
            <div
              style={{ left: `${highPct}%` }}
              className="absolute bottom-0 -translate-x-1/2 text-[10px] font-mono text-[#646059]"
            >
              {formatINR(band.high)}
            </div>

            {/* Current Price Dot with Floating Label */}
            <motion.div
              animate={{ left: `${currentPct}%` }}
              transition={{ type: 'spring', stiffness: 450, damping: 28 }}
              className="absolute top-7 -translate-x-1/2 pointer-events-none z-20 flex flex-col items-center"
            >
              <div
                style={{ backgroundColor: statusColor }}
                className="w-4 h-4 rounded-full border-2 border-white shadow-md"
              />

              <div
                className={`text-[10px] font-heading font-bold px-2.5 py-0.5 rounded-full border shadow-sm flex items-center gap-1 whitespace-nowrap bg-white text-[#141518] border-[#EBE5DB] ${
                  isCloseToTypical ? 'mt-3.5' : 'mt-1.5'
                }`}
              >
                <span className="font-mono font-extrabold">{formatINR(effectivePrice)}</span>
                <span style={{ color: statusColor }}>({statusLabel})</span>
              </div>
            </motion.div>
          </div>
        );
      })()}

      {/* Status Warning / Helper Strip */}
      <div
        className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 transition-colors ${
          status === 'fair' 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-950' 
            : 'bg-amber-50 border-amber-200 text-amber-950'
        }`}
      >
        {status === 'fair' ? (
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
        ) : (
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        )}
        <div className="flex-1">
          <p className="font-heading font-bold text-xs">
            {status === 'fair' ? 'Within Fair Band' : statusLabel}
          </p>
          <p className="text-[11px] mt-0.5 leading-relaxed font-sans opacity-90">
            {perspectiveHelper}
          </p>
        </div>
      </div>

      {/* Quick Snap Chips */}
      {triggerChange && (
        <div className="flex items-center gap-2 pt-2 border-t border-[#EBE5DB] text-xs">
          <span className="text-[11px] text-[#646059] font-heading font-bold">Snap to:</span>
          <button
            type="button"
            onClick={() => triggerChange(band.low)}
            className="px-3 py-1 rounded-full bg-[#F5F2EB] hover:bg-[#EBE5DB] text-[#141518] text-[11px] font-mono transition cursor-pointer"
          >
            Low: {formatINR(band.low)}
          </button>
          <button
            type="button"
            onClick={() => triggerChange(band.typical)}
            className="px-3 py-1 rounded-full bg-[#FFF1EC] hover:bg-[#FFE4DC] text-[#E85A32] text-[11px] font-mono font-bold transition cursor-pointer"
          >
            Median: {formatINR(band.typical)}
          </button>
          <button
            type="button"
            onClick={() => triggerChange(band.high)}
            className="px-3 py-1 rounded-full bg-[#F5F2EB] hover:bg-[#EBE5DB] text-[#141518] text-[11px] font-mono transition cursor-pointer"
          >
            High: {formatINR(band.high)}
          </button>
        </div>
      )}

      {/* Collapsible Math Explanation */}
      <div className="pt-2 border-t border-[#EBE5DB]">
        <button
          type="button"
          onClick={() => setShowExplanation(!showExplanation)}
          className="w-full flex items-center justify-between text-left text-xs text-[#646059] hover:text-[#141518] transition cursor-pointer"
        >
          <span className="flex items-center gap-1.5 font-heading font-bold">
            <Info className="w-3.5 h-3.5 text-[#E85A32]" />
            How is this calculated? ({band.jobCount} jobs, {band.outliersRemoved} outliers pruned)
          </span>
          {showExplanation ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        <AnimatePresence>
          {showExplanation && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden text-xs text-[#646059] mt-2 space-y-2 bg-[#FAF7F0] p-4 rounded-2xl border border-[#EBE5DB] font-sans"
            >
              <p className="text-[#141518] font-medium">{band.explanation}</p>
              <ul className="list-disc list-inside space-y-1 text-[#646059] text-[11px]">
                <li><strong>Outlier Removal:</strong> Values outside Q1 - 1.5&times;IQR and Q3 + 1.5&times;IQR are eliminated automatically.</li>
                <li><strong>Anti-Gaming Cap:</strong> Max 2 jobs per customer-worker pair per 7-day rolling window.</li>
                <li><strong>Weekly Velocity Bound:</strong> Band movements are capped at &plusmn;10% week-over-week.</li>
                <li><strong>Confidence Tiers:</strong> &ge;5 jobs = High confidence; 1–4 jobs = Low confidence; 0 = Category baseline estimate.</li>
              </ul>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
