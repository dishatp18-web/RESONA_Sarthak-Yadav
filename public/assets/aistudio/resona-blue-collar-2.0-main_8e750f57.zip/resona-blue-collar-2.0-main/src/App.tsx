/**
 * FairFix - Hyperlocal On-Demand Blue-Collar Services
 * Modern UI/UX Redesign matching ProFlow reference design.
 * Warm luminous atmosphere, electric-yellow CTA pills, terracotta accents,
 * and high-converting typography.
 */
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { DemoUserProvider, useDemoUser } from './context/DemoUserContext.js';
import { ToastProvider, ArcLoader } from './components/ui/index.js';
import { Navbar } from './components/Navbar.js';
import { CustomerNewRequest } from './components/CustomerNewRequest.js';
import { WorkerView } from './components/WorkerView.js';
import { FairPriceExplorer } from './components/FairPriceExplorer.js';
import { AdminPlaceholder } from './components/AdminPlaceholder.js';
import { DemoControls } from './components/DemoControls.js';
import { PublicTracker } from './components/PublicTracker.js';
import { BatchDispatch } from './components/BatchDispatch.js';
import { ConceptLab } from './components/ConceptLab.js';
import type { TabType } from './components/Navbar.js';
import { ShieldCheck, PhoneCall, Sparkles } from 'lucide-react';

function MainApp() {
  const [currentTab, setCurrentTab] = useState<TabType>('customer');
  const { loading } = useDemoUser();

  // Check if public tracking route is accessed (/track/:token)
  const isTrackRoute = typeof window !== 'undefined' && window.location.pathname.startsWith('/track/');
  const trackToken = isTrackRoute ? window.location.pathname.replace(/^\/track\//, '').split('/')[0] : null;

  if (isTrackRoute && trackToken) {
    return (
      <PublicTracker
        token={trackToken}
        onBackToApp={() => {
          window.history.pushState({}, '', '/');
          window.location.reload();
        }}
      />
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FBF9F4] flex flex-col items-center justify-center text-[#141518] relative z-10">
        <ArcLoader size="lg" className="mb-4" />
        <p className="font-heading font-bold text-base text-[#141518]">
          Initializing FairFix Hyperlocal Engine...
        </p>
        <p className="text-xs text-[#646059] mt-1 font-sans">Connecting SQLite &amp; loading Bengaluru seed market data</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FBF9F4] text-[#141518] flex flex-col font-sans selection:bg-[#FFEA00] selection:text-black relative">
      {/* Background Atmosphere: Warm Golden Sunburst Radial Glow */}
      <div className="forge-bg">
        <div className="forge-glow-gold" />
        <div className="forge-glow-red" />
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar currentTab={currentTab} setCurrentTab={setCurrentTab} />

        <main className="flex-1 pb-16">
          {currentTab === 'customer' && <CustomerNewRequest />}
          {currentTab === 'worker' && <WorkerView />}
          {currentTab === 'explorer' && <FairPriceExplorer />}
          {currentTab === 'dispatch' && <BatchDispatch />}
          {currentTab === 'lab' && <ConceptLab />}
          {currentTab === 'admin' && <AdminPlaceholder />}
        </main>

        {/* Polished Modern Footer */}
        <footer className="bg-white border-t border-[#EBE5DB] text-xs text-[#646059] py-6 px-4 mt-12">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-xl bg-[#121316] text-[#FFEA00] font-heading font-extrabold flex items-center justify-center text-sm shadow-sm">
                F
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-heading font-extrabold text-sm text-[#141518]">FairFix</span>
                  <span className="text-[10px] font-heading font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                    Live Fair-Price Band Active
                  </span>
                </div>
                <p className="text-[11px] text-[#646059] font-sans">
                  Hyperlocal on-demand blue-collar services &bull; Anti-gouging IQR pricing telemetry
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-xs font-heading font-medium">
              <span className="flex items-center gap-1.5 text-[#E85A32] font-bold">
                <PhoneCall className="w-3.5 h-3.5" />
                (555) 123-4567
              </span>
              <span>&bull;</span>
              <span className="flex items-center gap-1.5 text-neutral-700">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                100% Verified Local Tradespeople
              </span>
              <span>&bull;</span>
              <span className="text-[#646059] font-sans">
                Bengaluru: Koramangala &bull; HSR Layout &bull; Indiranagar &bull; Jayanagar &bull; Whitefield
              </span>
            </div>
          </div>
        </footer>

        {/* Floating Demo Simulator Controls */}
        <DemoControls />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <DemoUserProvider>
      <ToastProvider>
        <MainApp />
      </ToastProvider>
    </DemoUserProvider>
  );
}
